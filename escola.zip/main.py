import time
import sqlite3
import hashlib
import subprocess
import psutil
import os
import signal
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, render_template_string
import threading
import json
from pathlib import Path
import sys
import markdown
import requests

# Update version
LOCAL_VERSION = "1.1.0"

UPDATE_URL = "https://raw.githubusercontent.com/Davioli12/updater/refs/heads/main/update.json"

def check_update():
    try:
        r = requests.get(UPDATE_URL, timeout=5)
        r.raise_for_status()
        data = r.json()
        
        if data["version"] != LOCAL_VERSION:
            return True, data
        
        return False, None
    except Exception as e:
        print(f"Erro ao verificar atualização: {e}")
        return False, None

def download_update(url):
    r = requests.get(url, stream=True)
    
    with open("escola.zip", "wb") as f:
        for chunk in r.iter_content(1024):
            f.write(chunk)

def validate_update(file_path, expected_hash):
    h = hashlib.sha256()
    
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)
    
    return h.hexdigest() == expected_hash

# Verificação de atualização
has_update, data = check_update()

if has_update:
    download_update(data["url"])
    
    if validate_update("escola.zip", data["sha256"]):
        subprocess.Popen(["python", "escola.py"])
        exit()
    else:
        print("Update corrompido")


sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

app = Flask(__name__)
app.secret_key = 'sua-chave-secreta-aqui-mudar-em-producao'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=2)

# =====================
# CONFIGURAÇÃO DE LOGS
# =====================

LOGS_DIR = Path("logs")
LOGS_DIR.mkdir(exist_ok=True)

def get_log_path(service_name):
    """Retorna o caminho do arquivo de log de um serviço"""
    return LOGS_DIR / f"{service_name}.log"

# =====================
# GERENCIADOR DE SERVIÃ‡OS
# =====================

class ServiceManager:
    """Gerenciador de serviÃ§os que executa cada serviÃ§o em processo separado"""
    
    def __init__(self, config_file):
        self.config_file = config_file
        self.services = {}
        self.processes = {}
        self.load_config()
        self.load_runtime()

    
    def load_config(self):
        """Carrega configuraÃ§Ã£o dos serviÃ§os"""
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                self.services = json.load(f)
            print(f"[INFO] ConfiguraÃ§Ã£o carregada: {len(self.services)} serviÃ§o(s)")
        else:
            print(f"[AVISO] Arquivo {self.config_file} nÃ£o encontrado")
    
    def start(self, service_name, debug=False):
        """Inicia um serviço em processo separado"""
        
        if service_name not in self.services:
            raise ValueError(f"Serviço '{service_name}' não encontrado")
        
        if service_name in self.processes and self.is_running(service_name):
            print(f"[INFO] Serviço '{service_name}' já está rodando")
            return
        
        service = self.services[service_name]
        command = service.get('command')
        cwd = service.get('cwd', None)
        env = os.environ.copy()
        
        # Variáveis de ambiente customizadas
        if 'env' in service:
            env.update(service['env'])
        
        # Prepara arquivo de log
        log_file = get_log_path(service_name)
        
        try:
            if os.name == 'nt':  # Windows
                if debug:
                    # 🐞 DEBUG → terminal visível
                    process = subprocess.Popen(
                        f'cmd /k {command}',
                        shell=True,
                        cwd=cwd,
                        env=env
                    )
                else:
                    # 🚀 PRODUÇÃO → captura logs em arquivo
                    log_handle = open(log_file, 'w', encoding='utf-8')
                    process = subprocess.Popen(
                        command,
                        shell=True,
                        cwd=cwd,
                        env=env,
                        creationflags=(
                            subprocess.CREATE_NEW_PROCESS_GROUP |
                            subprocess.DETACHED_PROCESS |
                            subprocess.CREATE_NO_WINDOW
                        ),
                        stdout=log_handle,
                        stderr=subprocess.STDOUT
                    )

            else:  # Linux / Mac
                if debug:
                    # Terminal visível
                    process = subprocess.Popen(
                        command,
                        shell=True,
                        cwd=cwd,
                        env=env,
                        preexec_fn=os.setpgrp
                    )
                else:
                    # Logs em arquivo
                    log_handle = open(log_file, 'w', encoding='utf-8')
                    process = subprocess.Popen(
                        command,
                        shell=True,
                        cwd=cwd,
                        env=env,
                        preexec_fn=os.setpgrp,
                        stdout=log_handle,
                        stderr=subprocess.STDOUT
                    )
            
            self.processes[service_name] = {
                'process': process,
                'pid': process.pid,
                'started_at': datetime.now(),
                'debug': debug,
                'log_file': str(log_file) if not debug else None
            }
            
            self._save_runtime()
            
            mode = "DEBUG" if debug else "BACKGROUND"
            print(f"[INFO] Serviço '{service_name}' iniciado ({mode}) PID={process.pid}")
            if not debug:
                print(f"[INFO] Logs em: {log_file}")
        
        except Exception as e:
            print(f"[ERRO] Falha ao iniciar '{service_name}': {e}")
            raise

    def get_logs(self, service_name, lines=100):
        """Retorna as últimas N linhas do log de um serviço"""
        log_file = get_log_path(service_name)
        
        if not log_file.exists():
            return []
        
        try:
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                all_lines = f.readlines()
                return all_lines[-lines:] if len(all_lines) > lines else all_lines
        except Exception as e:
            return [f"[ERRO] Não foi possível ler o log: {e}"]
    
    def clear_logs(self, service_name):
        """Limpa o arquivo de log de um serviço"""
        log_file = get_log_path(service_name)
        
        if log_file.exists():
            try:
                log_file.unlink()
                print(f"[INFO] Log de '{service_name}' limpo")
                return True
            except Exception as e:
                print(f"[ERRO] Falha ao limpar log: {e}")
                return False
        return True

    def shutdown(self):
        print("[INFO] Encerrando todos os serviÃ§os...")

        for name in list(self.processes.keys()):
            self.kill(name)

        if os.path.exists("runtime.json"):
            os.remove("runtime.json")


    def _save_runtime(self):
        data = {}
        for name, info in self.processes.items():
            data[name] = {
                "pid": info["pid"],
                "started_at": info["started_at"].isoformat()
            }

        with open("runtime.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def get_ports(self, service_name):
        info = self.processes.get(service_name)
        if not info:
            return []

        pid = info.get("pid")
        if not pid or not psutil.pid_exists(pid):
            return []

        ports = set()

        try:
            parent = psutil.Process(pid)

            # Verifica o prÃ³prio processo
            for conn in parent.net_connections(kind="inet"):
                if conn.status == psutil.CONN_LISTEN and conn.laddr:
                    ports.add(conn.laddr.port)

            # Verifica TODOS os filhos (essencial no Windows)
            for child in parent.children(recursive=True):
                try:
                    for conn in child.net_connections(kind="inet"):
                        if conn.status == psutil.CONN_LISTEN and conn.laddr:
                            ports.add(conn.laddr.port)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

        return sorted(ports)

    def load_runtime(self):
        if not os.path.exists("runtime.json"):
            return

        with open("runtime.json", "r", encoding="utf-8") as f:
            data = json.load(f)

        for name, info in data.items():
            pid = info.get("pid")

            if pid and psutil.pid_exists(pid):
                self.processes[name] = {
                    "process": None,  # nÃ£o temos o Popen
                    "pid": pid,
                    "started_at": info.get("started_at")
                }
                print(f"[INFO] ServiÃ§o '{name}' detectado rodando (PID {pid})")

    def kill(self, service_name):
        info = self.processes.get(service_name)
        if not info:
            return

        pid = info["pid"]

        try:
            proc = psutil.Process(pid)

            for child in proc.children(recursive=True):
                child.kill()

            proc.kill()
            proc.wait()

            print(f"[INFO] ServiÃ§o '{service_name}' finalizado")

        except psutil.NoSuchProcess:
            pass

        self.processes.pop(service_name, None)


    def stop(self, service_name):
        info = self.processes.get(service_name)

        if not info:
            print(f"[INFO] ServiÃ§o '{service_name}' nÃ£o estÃ¡ registrado")
            return

        pid = info["pid"]

        try:
            proc = psutil.Process(pid)

            # Mata filhos primeiro (Flask, DayZ, etc.)
            for child in proc.children(recursive=True):
                child.kill()

            proc.kill()
            proc.wait()

            print(f"[INFO] ServiÃ§o '{service_name}' parado com sucesso")

        except psutil.NoSuchProcess:
            print(f"[WARN] Processo do serviÃ§o '{service_name}' nÃ£o existia mais")

        self.processes.pop(service_name, None)
        self._save_runtime()

    
    def restart(self, service_name):
        """Reinicia um serviÃ§o"""
        print(f"[INFO] Reiniciando serviÃ§o '{service_name}'...")
        self.stop(service_name)
        time.sleep(1)
        self.start(service_name)
    
    def is_running(self, service_name):
        info = self.processes.get(service_name)
        if not info:
            return False

        pid = info.get("pid")
        if not pid:
            return False

        if not psutil.pid_exists(pid):
            return False

        try:
            proc = psutil.Process(pid)

            # STATUS_ZOMBIE existe em Unix, mas nÃ£o no Windows
            if proc.status() == psutil.STATUS_ZOMBIE:
                return False

            return True

        except psutil.NoSuchProcess:
            return False
    
    def status(self, service_name):
        """Retorna status de um serviÃ§o"""
        if service_name not in self.services:
            return "unknown"
        
        if self.is_running(service_name):
            return "running"
        else:
            # Remove da lista se o processo morreu
            if service_name in self.processes:
                del self.processes[service_name]
            return "stopped"
    
    def auto_start_services(self):
        """Inicia serviÃ§os marcados como auto_start"""
        for name, config in self.services.items():
            if config.get('auto_start', False):
                try:
                    self.start(name)
                except Exception as e:
                    print(f"[ERRO] Falha no auto-start de '{name}': {e}")
                
    def get_service_status(self, service_name):
        running = self.is_running(service_name)
        ports = self.get_ports(service_name) if running else []

        return {
            "name": service_name,
            "status": "running" if running else "stopped",
            "pid": self.processes.get(service_name, {}).get("pid"),
            "ports": ports
        }
    
    def stop_all(self):
        """Para todos os serviÃ§os"""
        print("[INFO] Parando todos os serviÃ§os...")
        for service_name in list(self.processes.keys()):
            self.stop(service_name)
    
    def get_process_info(self, service_name):
        info = self.processes.get(service_name, {})

        pid = info.get("pid")

        # Determina se está rodando de forma REAL
        running = False
        if pid:
            try:
                running = psutil.pid_exists(pid)
            except Exception:
                running = False

        ports = self.get_ports(service_name) if running else []

        service_type = self.services.get(service_name, {}).get("type", "service")

        urls = []
        if service_type == "web" and running:
            for port in ports:
                urls.append(f"http://localhost:{port}")

        return {
            "name": service_name,
            "type": service_type,
            "running": running,
            "pid": pid,
            "ports": ports,
            "urls": urls
        }

# Inicializa o gerenciador de serviÃ§os
manager = ServiceManager("services.json")

# =====================
# BANCO DE DADOS
# =====================

def init_db():
    """Inicializa o banco de dados SQLite"""
    conn = sqlite3.connect('paas.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP
        )
    ''')
    
    # Cria usuÃ¡rio admin padrÃ£o (senha: admin123)
    admin_pass = hashlib.sha256('admin123'.encode()).hexdigest()
    try:
        c.execute('INSERT INTO users (username, password, email) VALUES (?, ?, ?)',
                  ('admin', admin_pass, 'admin@paas.local'))
        conn.commit()
        print("[INFO] UsuÃ¡rio admin criado (username: admin, password: admin123)")
    except sqlite3.IntegrityError:
        pass
    
    conn.close()

def get_db():
    """Retorna conexÃ£o com o banco de dados"""
    conn = sqlite3.connect('paas.db')
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password):
    """Gera hash SHA256 da senha"""
    return hashlib.sha256(password.encode()).hexdigest()

# =====================
# DECORADORES
# =====================

def login_required(f):
    """Decorator para rotas que exigem login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('VocÃª precisa estar logado para acessar esta pÃ¡gina', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# =====================
# ROTAS DE AUTENTICAÃ‡ÃƒO
# =====================

@app.route('/')
def index():
    """PÃ¡gina inicial - redireciona para dashboard se logado"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """PÃ¡gina de login"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Preencha todos os campos', 'danger')
            return render_template('login.html')
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ?', 
                           (username,)).fetchone()
        
        if user and user['password'] == hash_password(password):
            session.permanent = True
            session['user_id'] = user['id']
            session['username'] = user['username']
            
            # Atualiza Ãºltimo login
            conn.execute('UPDATE users SET last_login = ? WHERE id = ?',
                        (datetime.now(), user['id']))
            conn.commit()
            conn.close()
            
            flash(f'Bem-vindo, {username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            conn.close()
            flash('UsuÃ¡rio ou senha invÃ¡lidos', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """PÃ¡gina de registro"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        email = request.form.get('email')
        
        if not username or not password:
            flash('Preencha todos os campos obrigatÃ³rios', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('As senhas nÃ£o coincidem', 'danger')
            return render_template('register.html')
        
        if len(password) < 6:
            flash('A senha deve ter pelo menos 6 caracteres', 'danger')
            return render_template('register.html')
        
        conn = get_db()
        try:
            conn.execute('INSERT INTO users (username, password, email) VALUES (?, ?, ?)',
                        (username, hash_password(password), email))
            conn.commit()
            conn.close()
            flash('Conta criada com sucesso! FaÃ§a login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            flash('Nome de usuÃ¡rio jÃ¡ existe', 'danger')
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    """Faz logout do usuÃ¡rio"""
    session.clear()
    flash('VocÃª saiu com sucesso', 'info')
    return redirect(url_for('login'))

# =====================
# ROTAS PROTEGIDAS
# =====================

@app.route('/dashboard')
@login_required
def dashboard():
    """Dashboard principal com lista de serviÃ§os"""
    services_info = []

    for name, service in manager.services.items():
        status = manager.status(name)
        proc_info = manager.get_process_info(name)

        services_info.append({
            'name': name,
            'status': status,  # running / stopped
            'command': service.get('command', ''),
            'auto_start': service.get('auto_start', False),
            'process_info': {
                'running': proc_info.get('running', False),
                'pid': proc_info.get('pid'),
                'ports': proc_info.get('ports', [])
            }
        })

    return render_template(
        'dashboard.html',
        username=session['username'],
        services=services_info
    )

# Cole este código no seu main.py junto com as outras rotas /api/services

@app.route('/api/services/reload-config', methods=['POST'])
@login_required
def reload_config():
    """Recarrega o arquivo de configuração sem reiniciar o servidor"""
    try:
        # Recarrega o arquivo services.json
        manager.load_config()
        
        # Conta quantos serviços foram carregados
        total_services = len(manager.services)
        
        return jsonify({
            'success': True, 
            'message': f'Configuração recarregada: {total_services} serviço(s) encontrado(s)'
        })
    except FileNotFoundError:
        return jsonify({
            'success': False, 
            'message': 'Arquivo services.json não encontrado'
        }), 404
    except json.JSONDecodeError as e:
        return jsonify({
            'success': False, 
            'message': f'Erro ao ler JSON: {str(e)}'
        }), 400
    except Exception as e:
        return jsonify({
            'success': False, 
            'message': f'Erro ao recarregar configuração: {str(e)}'
        }), 500

@app.route("/api/services")
@login_required
def api_services():
    data = []

    for name in manager.services:
        info = manager.get_process_info(name)
        if info:
            data.append(info)

    return jsonify(data)

# Cole este código no seu main.py, ANTES da rota /api/service/<name>/start

@app.route('/api/service/<name>', methods=['GET'])
@login_required
def get_service(name):
    """Retorna dados de um serviço específico"""
    if name not in manager.services:
        return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404
    
    service = manager.services[name]
    return jsonify(service)

@app.route('/api/service/<name>', methods=['POST'])
@login_required
def create_service(name):
    """Cria um novo serviço"""
    if name in manager.services:
        return jsonify({'success': False, 'message': 'Serviço já existe'}), 400
    
    data = request.get_json()
    if not data or 'command' not in data:
        return jsonify({'success': False, 'message': 'Comando é obrigatório'}), 400
    
    manager.services[name] = {
        'command': data['command'],
        'auto_start': data.get('auto_start', False)
    }
    
    if 'cwd' in data and data['cwd']:
        manager.services[name]['cwd'] = data['cwd']
    if 'env' in data and data['env']:
        manager.services[name]['env'] = data['env']
    
    # Salva no arquivo
    try:
        with open(manager.config_file, 'w', encoding='utf-8') as f:
            json.dump(manager.services, f, indent=2, ensure_ascii=False)
        return jsonify({'success': True, 'message': f'Serviço {name} criado com sucesso'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/service/<name>', methods=['PUT'])
@login_required
def update_service_config(name):
    """Atualiza configuração de um serviço"""
    if name not in manager.services:
        return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404
    
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Dados inválidos'}), 400
    
    # Se o serviço estiver rodando, para ele primeiro
    if manager.is_running(name):
        manager.stop(name)
        time.sleep(0.5)
    
    # Atualiza os dados
    new_name = data.get('new_name')
    target_name = name
    
    if new_name and new_name != name:
        # Renomeia o serviço
        manager.services[new_name] = manager.services.pop(name)
        target_name = new_name
    
    if 'command' in data:
        manager.services[target_name]['command'] = data['command']
    if 'auto_start' in data:
        manager.services[target_name]['auto_start'] = data['auto_start']
    
    # Remove cwd e env se vazios
    if 'cwd' in data:
        if data['cwd']:
            manager.services[target_name]['cwd'] = data['cwd']
        elif 'cwd' in manager.services[target_name]:
            del manager.services[target_name]['cwd']
    
    if 'env' in data:
        if data['env']:
            manager.services[target_name]['env'] = data['env']
        elif 'env' in manager.services[target_name]:
            del manager.services[target_name]['env']
    
    # Salva no arquivo
    try:
        with open(manager.config_file, 'w', encoding='utf-8') as f:
            json.dump(manager.services, f, indent=2, ensure_ascii=False)
        return jsonify({'success': True, 'message': f'Serviço {target_name} atualizado com sucesso'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/service/<name>', methods=['DELETE'])
@login_required
def delete_service_config(name):
    """Remove um serviço"""
    if name not in manager.services:
        return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404
    
    # Para o serviço se estiver rodando
    if manager.is_running(name):
        manager.stop(name)
        time.sleep(0.5)
    
    # Remove do dicionário
    del manager.services[name]
    
    # Salva no arquivo
    try:
        with open(manager.config_file, 'w', encoding='utf-8') as f:
            json.dump(manager.services, f, indent=2, ensure_ascii=False)
        return jsonify({'success': True, 'message': f'Serviço {name} removido com sucesso'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/service/<name>/start', methods=['POST'])
@login_required
def start_service(name):
    """Inicia um serviço (background ou debug)"""
    try:
        # Tenta ler JSON da requisição (caso não exista, usa dict vazio)
        data = request.get_json(silent=True) or {}

        # Flag de debug (padrão: False)
        debug = bool(data.get('debug', False))

        # Inicia o serviço com ou sem terminal
        manager.start(name, debug=debug)

        # Mensagem amigável de retorno
        mode = "em modo DEBUG" if debug else "em background"

        return jsonify({
            'success': True,
            'service': name,
            'debug': debug,
            'message': f"Serviço '{name}' iniciado {mode}"
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'service': name,
            'message': str(e)
        }), 400

@app.route('/logs/<service_name>')
@login_required
def view_logs(service_name):
    """Página de visualização de logs"""
    if service_name not in manager.services:
        flash('Serviço não encontrado', 'danger')
        return redirect(url_for('dashboard'))
    
    service = manager.services[service_name]
    status = manager.status(service_name)
    
    return render_template('logs.html', 
                         service_name=service_name,
                         service=service,
                         status=status)


@app.route('/api/service/<name>/logs')
@login_required
def get_service_logs(name):
    """Retorna os logs de um serviço"""
    if name not in manager.services:
        return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404
    
    lines = request.args.get('lines', 100, type=int)
    logs = manager.get_logs(name, lines)
    
    return jsonify({
        'success': True,
        'service': name,
        'logs': logs,
        'total_lines': len(logs)
    })

@app.route('/api/service/<name>/logs/clear', methods=['POST'])
@login_required
def clear_service_logs(name):
    """Limpa os logs de um serviço"""
    if name not in manager.services:
        return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404
    
    success = manager.clear_logs(name)
    
    if success:
        return jsonify({'success': True, 'message': f'Logs de {name} limpos com sucesso'})
    else:
        return jsonify({'success': False, 'message': 'Falha ao limpar logs'}), 500

@app.route('/api/service/<name>/stop', methods=['POST'])
@login_required
def stop_service(name):
    """Para um serviÃ§o"""
    try:
        manager.stop(name)
        return jsonify({'success': True, 'message': f'ServiÃ§o {name} parado'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400
    
@app.route('/api/services/stop-all', methods=['POST'])
@login_required
def stop_all_services():
    """Para todos os serviços"""
    try:
        manager.stop_all()
        return jsonify({'success': True, 'message': 'Todos os serviços foram parados'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/service/<name>/restart', methods=['POST'])
@login_required
def restart_service(name):
    """Reinicia um serviÃ§o"""
    try:
        manager.restart(name)
        return jsonify({'success': True, 'message': f'ServiÃ§o {name} reiniciado'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/service/<name>/status')
@login_required
def service_status(name):
    """Retorna status de um serviÃ§o"""
    status = manager.status(name)
    proc_info = manager.get_process_info(name)
    return jsonify({
        'name': name, 
        'status': status,
        'process_info': proc_info
    })

@app.route('/profile')
@login_required
def profile():
    """PÃ¡gina de perfil do usuÃ¡rio"""
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', 
                       (session['user_id'],)).fetchone()
    conn.close()
    return render_template('profile.html', user=user)

@app.route('/docs')
def docs():
    base_dir = os.path.abspath(os.path.dirname(__file__))
    readme_path = os.path.join(base_dir, 'README.md')

    with open(readme_path, 'r', encoding='utf-8') as f:
        md_content = f.read()

    html_content = markdown.markdown(md_content, extensions=['fenced_code', 'tables'])

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Documentação</title>
        <style>
            /* Reset básico */
* {
    box-sizing: border-box;
}

/* Corpo da página */
body {
    margin: 0;
    padding: 40px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI",
                 Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans",
                 "Helvetica Neue", sans-serif;
    background-color: #0f1115;
    color: #e6e6e6;
    line-height: 1.7;
}

/* Container central */
.docs-container {
    max-width: 900px;
    margin: auto;
}

/* Títulos */
h1, h2, h3, h4, h5, h6 {
    color: #ffffff;
    margin-top: 2rem;
    margin-bottom: 1rem;
    font-weight: 600;
}

h1 {
    font-size: 2.2rem;
    border-bottom: 2px solid #2a2d36;
    padding-bottom: 10px;
}

h2 {
    font-size: 1.7rem;
    border-left: 4px solid #4da3ff;
    padding-left: 12px;
}

h3 {
    font-size: 1.4rem;
}

/* Parágrafos */
p {
    margin: 1rem 0;
    color: #d0d0d0;
}

/* Links */
a {
    color: #4da3ff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

/* Listas */
ul, ol {
    margin: 1rem 0 1rem 1.5rem;
}

li {
    margin: 0.4rem 0;
}

/* Blocos de código */
pre {
    background: #161a22;
    border-radius: 8px;
    padding: 16px;
    overflow-x: auto;
    margin: 1.5rem 0;
    border: 1px solid #232734;
}

code {
    font-family: "Fira Code", "JetBrains Mono", monospace;
    font-size: 0.95rem;
}

/* Código inline */
p code, li code {
    background: #1d2230;
    padding: 3px 6px;
    border-radius: 4px;
    color: #ffcc66;
}

/* Tabelas */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 1.5rem 0;
    background: #141820;
}

th, td {
    border: 1px solid #2a2f3a;
    padding: 10px;
    text-align: left;
}

th {
    background: #1c2230;
    font-weight: 600;
}

/* Citações */
blockquote {
    border-left: 4px solid #4da3ff;
    background: #141820;
    padding: 10px 15px;
    margin: 1.5rem 0;
    color: #cfd8ff;
}

/* Separador */
hr {
    border: none;
    height: 1px;
    background: #2a2f3a;
    margin: 2rem 0;
}

/* Imagens */
img {
    max-width: 100%;
    border-radius: 8px;
    margin: 1rem 0;
}

/* Scrollbar (Chrome / Edge) */
::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: #0f1115;
}

::-webkit-scrollbar-thumb {
    background: #2a2f3a;
    border-radius: 6px;
}

::-webkit-scrollbar-thumb:hover {
    background: #3a3f4a;
}

        </style>
    </head>
    <body>
        {{ content|safe }}
    </body>
    </html>
    """, content=html_content)

# =====================
# INICIALIZAÃ‡ÃƒO
# =====================

def find_available_port(start_port=5010, end_port=5030):
    """Encontra uma porta disponÃ­vel no range especificado"""
    import socket
    for port in range(start_port, end_port + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('0.0.0.0', port))
                return port
        except OSError:
            continue
    raise RuntimeError(f"Nenhuma porta disponÃ­vel entre {start_port} e {end_port}")

def run_web(port):
    """Executa o servidor web Flask"""
    app.run(
        host="0.0.0.0",
        port=port,
        debug=True,
        use_reloader=False,
        threaded=True
    )

def main():
    print("===================================")
    print(" PaaS Local - Central de ServiÃ§os ")
    print("===================================")
    
    # Inicializa banco de dados
    init_db()
    
    # Inicia serviÃ§os marcados como auto_start
    manager.auto_start_services()
    
    print("\n[INFO] ServiÃ§os configurados:")
    for name in manager.services:
        status = manager.status(name)
        auto = "âœ“ auto-start" if manager.services[name].get('auto_start') else ""
        print(f"  - {name}: {status} {auto}")
    
    # Encontra porta disponÃ­vel
    try:
        port = find_available_port()
        print(f"\n[INFO] PaaS Web iniciado com sucesso")
        print(f"[INFO] Acesse: http://localhost:{port}")
        print(f"[INFO] Login padrÃ£o: admin / admin123")
        print(f"[INFO] Porta {port} selecionada\n")
    except RuntimeError as e:
        print(f"[ERRO] {e}")
        return
    
    # Inicia servidor Flask em thread separada
    try:
        web_thread = threading.Thread(target=run_web, args=(port,), daemon=True)
        web_thread.start()
        
        # Aguarda a thread iniciar
        time.sleep(2)
        print("[INFO] Servidor web rodando. Pressione Ctrl+C para encerrar.")
        
        # Loop principal para manter o programa rodando
        while True:
            time.sleep(1)
    
    except KeyboardInterrupt:
        print("\n[INFO] Encerrando PaaS...")
        manager.stop_all()
        print("[INFO] PaaS finalizado com seguranÃ§a")

if __name__ == "__main__":
    main()