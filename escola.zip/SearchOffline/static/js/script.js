const paginas = [
    { titulo: "História", url: "materia/historia" },
    { titulo: "Matemática", url: "materia/matematica" },
    { titulo: "Ciências", url: "materia/ciencias" },
    { titulo: "Dino", url: "game"},
    { titulo: "Meus Arquivos", url: "arquivos"},
    { titulo: "Youtube", url: "youtube"},
    { titulo: "GitHub", url: "github"},
    { titulo: "Xhub", url: "xhub"},
    { titulo: "Notas", url: "notas"},
    { titulo: "Desenvolvedor", url: "dev" },
    { titulo: "Atualizações", url: "atualizacoes"},
    { titulo: "Materias", url: "materia"},
    { titulo: "IA", url: "ia.dev"},
];

function buscar() {
    let input = document.getElementById("search");
    let query = input.value.toLowerCase();
    let resultados = document.getElementById("results");
    resultados.innerHTML = "Desenvolvedor: Davi de Oliveira Santos, Chat GPT";

    let primeiroItem = null;

    paginas.forEach(pagina => {
        if (pagina.titulo.toLowerCase().includes(query)) {
            let item = document.createElement("li");
            let link = document.createElement("a");
            link.href = pagina.url;
            link.textContent = pagina.titulo;
            item.appendChild(link);
            resultados.appendChild(item);

            if (!primeiroItem) {
                primeiroItem = link; // Salva o primeiro link encontrado
            }
        }
    });

    // Mantém o foco na barra de pesquisa
    input.focus();
}

// Captura a tecla "Enter" para redirecionar para o primeiro resultado
document.getElementById("search").addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        let primeiroLink = document.querySelector("#results a");
        if (primeiroLink) {
            window.location.href = primeiroLink.href;
        }
    }
});
