// Lista de arquivos disponíveis no site
const files = [
    { name: "Teste", path: "../arquivos/arquivo_teste.pdf" },
    { name: "Notas.txt", path: "../arquivos/notas.txt" },
];

// Referência à lista de arquivos
const fileList = document.getElementById("file-list");

// Adiciona os arquivos na página
files.forEach(file => {
    const li = document.createElement("li");

    // Nome do arquivo
    const fileName = document.createElement("span");
    fileName.textContent = file.name;

    // Botão de Visualização
    const viewButton = document.createElement("button");
    viewButton.textContent = "Ver";
    viewButton.onclick = () => visualizarArquivo(file.path);

    // Botão de Download
    const downloadButton = document.createElement("button");
    downloadButton.textContent = "Baixar";
    downloadButton.onclick = () => baixarArquivo(file.path);

    // Adiciona elementos à lista
    li.appendChild(fileName);
    li.appendChild(viewButton);
    li.appendChild(downloadButton);
    fileList.appendChild(li);
});

// Função para visualizar arquivos (abre em uma nova aba se for compatível)
function visualizarArquivo(caminho) {
    window.open(caminho, "_blank");
}

// Função para baixar arquivos
function baixarArquivo(caminho) {
    const link = document.createElement("a");
    link.href = caminho;
    link.download = caminho.split("/").pop(); // Define o nome do arquivo para download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
