const chatbox = document.getElementById('chatbox');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

function addMessage(message, sender) {
    const messageElement = document.createElement('div');
    messageElement.className = sender;
    messageElement.textContent = message;
    chatbox.appendChild(messageElement);
    chatbox.scrollTop = chatbox.scrollHeight;
}

sendButton.addEventListener('click', async () => {
    const message = userInput.value.trim();
    if (!message) return;

    addMessage(`Você: ${message}`, 'user');
    userInput.value = '';

    try {
        const response = await fetch('ia.dev/api', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });

        const data = await response.json();
        addMessage(`IA: ${data.response}`, 'ia');
    } catch (error) {
        console.error('Erro:', error);
    }
});
