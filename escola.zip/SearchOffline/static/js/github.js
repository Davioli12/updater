// ==========================
// REGISTRO DE USUÁRIO
// ==========================
function register() {
    const user = document.getElementById("username").value.trim();
    const pass = document.getElementById("password").value;

    if (!user || !pass) {
        alert("Preencha usuário e senha.");
        return;
    }

    // Verifica se o usuário já existe
    if (localStorage.getItem("user_" + user)) {
        alert("Usuário já existe.");
        return;
    }

    localStorage.setItem("user_" + user, pass);
    alert("Usuário registrado com sucesso!");
}
// ==========================
// LOGIN
// ==========================
function login() {
    const user = document.getElementById("username").value.trim();
    const pass = document.getElementById("password").value;

    if (!user || !pass) {
        alert("Preencha usuário e senha.");
        return;
    }

    const savedPass = localStorage.getItem("user_" + user);

    if (!savedPass) {
        alert("Usuário não encontrado.");
        return;
    }

    if (savedPass !== pass) {
        alert("Senha incorreta.");
        return;
    }

    localStorage.setItem("loggedUser", user);
    window.location.href = "/github/inicio";
}
// ==========================
// LOGOUT
// ==========================
function logout() {
    localStorage.removeItem("loggedUser");
    window.location.href = "/github";
}
// ==========================
// UPLOAD DE ARQUIVO
// ==========================
function uploadFile() {
    const user = localStorage.getItem("loggedUser");

    if (!user) {
        alert("Usuário não autenticado.");
        window.location.href = "/github";
        return;
    }

    const input = document.getElementById("fileInput");
    if (!input || !input.files.length) {
        alert("Selecione um arquivo.");
        return;
    }

    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = function (e) {
        const key = "files_" + user;
        const files = JSON.parse(localStorage.getItem(key)) || [];

        files.push({
            name: file.name,
            data: e.target.result
        });

        localStorage.setItem(key, JSON.stringify(files));
        alert("Arquivo salvo com sucesso!");
        window.location.href = "/github/inicio";
    };

    reader.readAsDataURL(file);
}
// ==========================
// LISTAR ARQUIVOS
// ==========================
function loadFiles() {
    const user = localStorage.getItem("loggedUser");

    if (!user) {
        alert("Sessão expirada.");
        window.location.href = "/github";
        return;
    }

    const fileList = document.getElementById("fileList");
    if (!fileList) return;

    const files = JSON.parse(localStorage.getItem("files_" + user)) || [];
    fileList.innerHTML = "";

    files.forEach(file => {
        const li = document.createElement("li");
        const a = document.createElement("a");

        a.href = file.data;
        a.download = file.name;
        a.textContent = file.name;

        li.appendChild(a);
        fileList.appendChild(li);
    });
}
