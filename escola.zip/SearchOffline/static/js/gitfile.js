document.addEventListener("DOMContentLoaded", loadFiles);

// ==========================
// UPLOAD DE ARQUIVO REAL
// ==========================
function uploadFile() {
    const input = document.getElementById("fileInput");

    if (!input || !input.files.length) {
        alert("Selecione um arquivo.");
        return;
    }

    const formData = new FormData();
    formData.append("file", input.files[0]);

    fetch("/github/upload", {
        method: "POST",
        body: formData
    })
    .then(res => {
        if (!res.ok) throw new Error("Erro no upload");
        return res.json();
    })
    .then(() => {
        alert("Arquivo enviado com sucesso!");
        window.location.href = "/github/inicio";
    })
    .catch(err => {
        alert("Erro ao enviar arquivo.");
        console.error(err);
    });
}
