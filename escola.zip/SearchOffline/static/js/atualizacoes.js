// ===============================
// CARREGAR ATUALIZAÇÕES (JSON)
// ===============================
async function carregarAtualizacoes() {
    try {
        // Arquivo precisa estar dentro de /static
        const response = await fetch('/static/dados/atualizacoes.json');

        if (!response.ok) {
            throw new Error('Erro ao carregar atualizações');
        }

        const dados = await response.json();
        const lista = document.getElementById('updates-list');

        // Limpa a lista antes de preencher
        lista.innerHTML = '';

        dados.atualizacoes.forEach(atualizacao => {
            const item = document.createElement('li');

            item.innerHTML = `
                <strong>Versão ${atualizacao.versao} - ${atualizacao.data}:</strong>
                ${atualizacao.descricao}
            `;

            lista.appendChild(item);
        });

    } catch (error) {
        console.error('Falha ao carregar atualizações:', error);
    }
}

// Executa quando o script é carregado
document.addEventListener('DOMContentLoaded', carregarAtualizacoes);
