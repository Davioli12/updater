import json
import os
import pickle
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import numpy as np

BASE_DIR = os.path.dirname(__file__)
TRAIN_FILE = os.path.join(BASE_DIR, "training_data.json")
MODEL_FILE = os.path.join(BASE_DIR, "model.pkl")
VECTORIZER_FILE = os.path.join(BASE_DIR, "vectorizer.pkl")

class LocalIA:
    def __init__(self, auto_train=True, use_cache=True):
        """
        Inicializa a IA Local
        
        Args:
            auto_train: Se True, treina automaticamente ao inicializar
            use_cache: Se True, tenta carregar modelo salvo antes de treinar
        """
        self.vectorizer = TfidfVectorizer(
            max_features=500,  # Limita features para melhor performance
            ngram_range=(1, 2),  # Usa unigramas e bigramas
            min_df=1,  # Mínimo de documentos para uma palavra ser considerada
            strip_accents='unicode',  # Remove acentos
            lowercase=True  # Converte tudo para minúsculas
        )
        
        self.model = LogisticRegression(
            max_iter=1000,  # Aumenta iterações para melhor convergência
            C=1.0,  # Regularização
            solver='lbfgs',  # Solver eficiente
            random_state=42  # Reprodutibilidade
        )
        
        self.intents = []
        self.is_trained = False
        self.training_date = None
        self.accuracy = None
        
        # Tenta carregar modelo em cache
        if use_cache and self._load_cache():
            print("Modelo carregado do cache!")
        elif auto_train:
            self.train()

    def train(self, save_cache=True, show_report=False):
        """
        Treina o modelo com os dados do arquivo JSON
        
        Args:
            save_cache: Se True, salva o modelo treinado em arquivo
            show_report: Se True, exibe relatório de métricas
        """
        print("Iniciando treinamento da IA...")
        
        # Carrega dados de treinamento
        with open(TRAIN_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        texts = []
        labels = []

        # Prepara dados
        for intent, phrases in data.items():
            for phrase in phrases:
                texts.append(phrase.lower().strip())
                labels.append(intent)

        self.intents = list(data.keys())
        
        print(f"Total de intents: {len(self.intents)}")
        print(f"Total de exemplos: {len(texts)}")

        # Divide em treino e teste para validação
        X_train, X_test, y_train, y_test = train_test_split(
            texts, labels, test_size=0.2, random_state=42, stratify=labels
        )

        # Vetoriza os textos
        X_train_vec = self.vectorizer.fit_transform(X_train)
        X_test_vec = self.vectorizer.transform(X_test)

        # Treina o modelo
        self.model.fit(X_train_vec, y_train)

        # Calcula acurácia
        y_pred = self.model.predict(X_test_vec)
        self.accuracy = accuracy_score(y_test, y_pred)
        
        self.is_trained = True
        self.training_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        print(f"Treinamento concluído!")
        print(f"Acurácia: {self.accuracy * 100:.2f}%")

        # Mostra relatório detalhado se solicitado
        if show_report:
            print("\nRelatório de Classificação:")
            print(classification_report(y_test, y_pred, zero_division=0))

        # Salva modelo em cache
        if save_cache:
            self._save_cache()

    def predict(self, message: str, return_probabilities=False):
        """
        Prediz a intenção da mensagem
        
        Args:
            message: Texto da mensagem
            return_probabilities: Se True, retorna todas as probabilidades
            
        Returns:
            Se return_probabilities=False: (intent, confidence)
            Se return_probabilities=True: (intent, confidence, all_probabilities)
        """
        if not self.is_trained:
            raise Exception("Modelo não foi treinado! Execute .train() primeiro.")

        # Pré-processa mensagem
        message = message.lower().strip()
        
        # Vetoriza
        X = self.vectorizer.transform([message])
        
        # Prediz
        intent = self.model.predict(X)[0]
        probabilities = self.model.predict_proba(X)[0]
        confidence = max(probabilities)
        
        if return_probabilities:
            # Retorna todas as probabilidades ordenadas
            intent_probs = dict(zip(self.model.classes_, probabilities))
            sorted_probs = dict(sorted(intent_probs.items(), key=lambda x: x[1], reverse=True))
            return intent, confidence, sorted_probs
        
        return intent, confidence

    def predict_top_n(self, message: str, n=3):
        """
        Retorna os top N intents mais prováveis
        
        Args:
            message: Texto da mensagem
            n: Número de top intents para retornar
            
        Returns:
            Lista de tuplas (intent, confidence)
        """
        intent, confidence, all_probs = self.predict(message, return_probabilities=True)
        
        top_n = list(all_probs.items())[:n]
        return top_n

    def evaluate_message(self, message: str):
        """
        Avalia uma mensagem e retorna análise detalhada
        
        Args:
            message: Texto da mensagem
            
        Returns:
            Dicionário com análise completa
        """
        intent, confidence, all_probs = self.predict(message, return_probabilities=True)
        top_3 = list(all_probs.items())[:3]
        
        # Determina nível de confiança
        if confidence >= 0.70:
            confidence_level = "Alta"
        elif confidence >= 0.50:
            confidence_level = "Boa"
        elif confidence >= 0.35:
            confidence_level = "Média"
        elif confidence >= 0.25:
            confidence_level = "Baixa"
        else:
            confidence_level = "Muito Baixa"
        
        return {
            "message": message,
            "intent": intent,
            "confidence": round(confidence, 4),
            "confidence_level": confidence_level,
            "top_3_intents": [(i, round(c, 4)) for i, c in top_3],
            "should_respond": confidence >= 0.25
        }

    def get_info(self):
        """Retorna informações sobre o modelo"""
        return {
            "is_trained": self.is_trained,
            "training_date": self.training_date,
            "accuracy": round(self.accuracy * 100, 2) if self.accuracy else None,
            "total_intents": len(self.intents),
            "intents": self.intents,
            "vectorizer_features": self.vectorizer.max_features,
            "model_type": type(self.model).__name__
        }

    def retrain(self):
        """Retreina o modelo do zero"""
        print("Retreinando modelo...")
        self.train(save_cache=True, show_report=True)

    def _save_cache(self):
        """Salva modelo e vetorizador em arquivo"""
        try:
            with open(MODEL_FILE, 'wb') as f:
                pickle.dump(self.model, f)
            
            with open(VECTORIZER_FILE, 'wb') as f:
                pickle.dump(self.vectorizer, f)
            
            # Salva metadados
            metadata = {
                "training_date": self.training_date,
                "accuracy": self.accuracy,
                "intents": self.intents
            }
            
            metadata_file = os.path.join(BASE_DIR, "model_metadata.json")
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)
            
            print("Modelo salvo em cache com sucesso!")
        except Exception as e:
            print(f"Erro ao salvar cache: {e}")

    def _load_cache(self):
        """Carrega modelo e vetorizador do arquivo"""
        try:
            if not (os.path.exists(MODEL_FILE) and os.path.exists(VECTORIZER_FILE)):
                return False
            
            with open(MODEL_FILE, 'rb') as f:
                self.model = pickle.load(f)
            
            with open(VECTORIZER_FILE, 'rb') as f:
                self.vectorizer = pickle.load(f)
            
            # Carrega metadados
            metadata_file = os.path.join(BASE_DIR, "model_metadata.json")
            if os.path.exists(metadata_file):
                with open(metadata_file, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                    self.training_date = metadata.get("training_date")
                    self.accuracy = metadata.get("accuracy")
                    self.intents = metadata.get("intents", [])
            
            self.is_trained = True
            return True
        except Exception as e:
            print(f"Erro ao carregar cache: {e}")
            return False


# ============================================
# EXEMPLO DE USO
# ============================================
if __name__ == "__main__":
    # Inicializa e treina
    ia = LocalIA(auto_train=True, use_cache=True)
    
    # Mostra informações
    print("\n" + "="*50)
    print("INFORMAÇÕES DO MODELO")
    print("="*50)
    info = ia.get_info()
    for key, value in info.items():
        print(f"{key}: {value}")
    
    # Testa algumas mensagens
    print("\n" + "="*50)
    print("TESTES DE PREDIÇÃO")
    print("="*50)
    
    test_messages = [
        "olá, tudo bem?",
        "como você funciona?",
        "tchau",
        "obrigado pela ajuda",
        "me conta uma piada"
    ]
    
    for msg in test_messages:
        result = ia.evaluate_message(msg)
        print(f"\nMensagem: '{msg}'")
        print(f"   Intent: {result['intent']}")
        print(f"   Confiança: {result['confidence']*100:.2f}% ({result['confidence_level']})")
        print(f"   Top 3: {result['top_3_intents']}")