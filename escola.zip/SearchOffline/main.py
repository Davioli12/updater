import os
from flask import Flask, render_template, jsonify, request, send_from_directory, redirect
from flask_cors import CORS
from werkzeug.utils import secure_filename
import json
import random
from datetime import datetime

# =========================
# Inicialização
# =========================
app = Flask(
    __name__,
    template_folder="templates",
    static_folder="static"
)

CORS(app)

PORT = int(os.environ.get("PORT", 5004))
UPLOAD_FOLDER = "static/uploads"
MEMORY_FILE = "ia/memory.json"


# =========================
# Página principal
# =========================
@app.route("/")
def index():
    return render_template("index.html")


# =========================
# Matérias
# =========================
@app.route("/materia")
def materias():
    return render_template("materias.html")


@app.route("/materia/historia")
def historia():
    return render_template("historia.html")


@app.route("/materia/matematica")
def matematica():
    return render_template("matematica.html")


@app.route("/materia/ciencias")
def ciencias():
    return render_template("ciencias.html")


# =========================
# Jogos
# =========================
@app.route("/game")
def game():
    return render_template("web-dino/index.html")


# =========================
# Arquivos e páginas extras
# =========================
@app.route("/arquivos")
def arquivos():
    return render_template("archivers.html")

@app.route("/xhub")
def xhub():
    args = request.args

    if "admin" in args or args.get("arg") == "admin":
        return render_template("xhub/index.html")

    return render_template("error.html")


# Armazenamento simples em memória (didático)
notas = []

@app.route("/notas", methods=["GET", "POST"])
def notas_view():
    if request.method == "POST":
        texto = request.form.get("texto", "").strip()
        arquivo = request.files.get("file")

        filename = None

        # Se tiver arquivo, salva
        if arquivo and arquivo.filename:
            filename = secure_filename(arquivo.filename)
            arquivo.save(os.path.join(UPLOAD_FOLDER, filename))

        # Salva nota em memória
        notas.append({
            "texto": texto,
            "arquivo": filename
        })

        return redirect("/notas")

    # GET → renderiza página
    return render_template("notas.html", notas=notas)


# ==========================
# DOWNLOAD DE ARQUIVOS
# ==========================
@app.route("/notas/uploads/<filename>")
def download_file_notas(filename):
    return send_from_directory(
        UPLOAD_FOLDER,
        filename,
        as_attachment=True
    )


@app.route("/dev")
def dev():
    return render_template("dev.html")


@app.route("/in-dev")
def in_dev():
    return render_template("in-dev.html")


# =========================
# GitHub fake
# =========================
@app.route("/github")
def github():
    return render_template("github/github.html")

@app.route("/github/upload", methods=["GET", "POST"])
def github_upload():
    # ======================
    # GET → abre a página
    # ======================
    if request.method == "GET":
        return render_template("github/upload.html")

    # ======================
    # POST → recebe arquivo
    # ======================
    if "file" not in request.files:
        return jsonify({"error": "Arquivo não enviado"}), 400

    file = request.files["file"]

    if file.filename == "":
        return jsonify({"error": "Nome inválido"}), 400

    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    filename = secure_filename(file.filename)
    file.save(os.path.join(UPLOAD_FOLDER, filename))

    return jsonify({"success": True})

@app.route("/github/download/<filename>")
def download_file(filename):
    return send_from_directory(
        UPLOAD_FOLDER,
        filename,
        as_attachment=True
    )

@app.route("/github/inicio")
def github_dashboard():
    files = []

    if os.path.exists("uploads"):
        files = os.listdir("uploads")

    return render_template("github/dashboard.html", files=files)


# =========================
# Atualizações
# =========================
@app.route("/atualizacoes")
def atualizacoes():
    return render_template("atualizacoes/index.html")


# =========================
# YouTube local
# =========================
@app.route("/youtube")
def youtube():
    return render_template("youtube/index.html")


@app.route("/youtube/video")
def youtube_video():
    return render_template("youtube/video.html")


@app.route("/youtube/videos")
def youtube_videos():
    video_dir = os.path.join(app.static_folder, "videos")
    try:
        files = os.listdir(video_dir)
        return jsonify(files)
    except Exception:
        return jsonify([]), 500


@app.route("/youtube/<video>")
def youtube_stream(video):
    video_path = os.path.join(app.static_folder, "videos", video)
    if os.path.exists(video_path):
        return app.send_static_file(f"videos/{video}")
    return "Vídeo não encontrado", 404


# =========================
# IA simples
# =========================
from ia.model import LocalIA
ia = LocalIA(auto_train=True, use_cache=True)
print(f"IA pronta! Acurácia: {ia.accuracy:.2f}%" if ia.accuracy else "IA pronta!")

conversation_memory = []

def save_memory(user, message, response):
    """Salva conversa na memória"""
    conversation_memory.append({
        "user": user,
        "message": message,
        "response": response,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    # Mantém apenas as últimas 100 conversas
    if len(conversation_memory) > 100:
        conversation_memory.pop(0)

# ============================================
# RESPOSTAS DINÂMICAS
# ============================================
DYNAMIC_RESPONSES = {
    "saudacao": [
        "Olá! Como posso ajudar?",
        "Oi! No que posso ser útil hoje?",
        "Hey! Em que posso ajudar você?",
        "E aí! Pronto para conversar?",
        "Olá! É um prazer falar com você!",
        "Oi! Estou aqui para ajudar no que precisar!",
        "Seja bem-vindo! Como posso auxiliar?"
    ],
    "funcionamento": [
        "Sou uma IA local criada em Python, sem internet.",
        "Sou um assistente virtual desenvolvido em Python que funciona offline.",
        "Fui programada em Python para funcionar localmente, sem precisar de conexão.",
        "Sou uma inteligência artificial local, criada com Python e machine learning.",
        "Funciono completamente offline, processando tudo localmente em Python!"
    ],
    "despedida": [
        "Até mais!",
        "Tchau! Foi bom conversar!",
        "Até logo! Volte sempre!",
        "Falou! Estarei aqui quando precisar!",
        "Até a próxima! Cuide-se!",
        "Tchau tchau! Foi um prazer ajudar!"
    ],
    "agradecimento": [
        "Por nada! Fico feliz em ajudar!",
        "Disponha! Estou aqui para isso!",
        "De nada! Foi um prazer auxiliar você!",
        "Imagina! Sempre que precisar, pode chamar!",
        "Sem problemas! É bom poder ser útil!",
        "Que bom que consegui ajudar!"
    ],
    "confirmacao": [
        "Entendido!",
        "Ok, pode deixar!",
        "Certo! Vamos lá!",
        "Perfeito! Entendi!",
        "Beleza! Captei!",
        "Ótimo! Compreendi!"
    ],
    "negacao": [
        "Ok, sem problemas!",
        "Tudo bem! Como prefere!",
        "Entendi, não tem problema!",
        "Tranquilo! Respeitando sua escolha!",
        "Beleza! Vamos fazer diferente então!"
    ],
    "ajuda": [
        "Estou aqui para ajudar! O que você precisa?",
        "Claro! Me diz o que você quer saber!",
        "Pode perguntar! Vou fazer o melhor para ajudar!",
        "Conte comigo! Qual sua dúvida?",
        "Estou à disposição! Como posso auxiliar?"
    ],
    "capacidades": [
        "Posso conversar, responder perguntas e ajudar com informações diversas!",
        "Consigo entender texto, processar intenções e dar respostas úteis!",
        "Fui treinada para reconhecer vários tipos de mensagens e responder adequadamente!",
        "Posso ajudar com conversas, dúvidas e informações gerais!"
    ],
    "estado_humor": [
        "Estou funcionando perfeitamente! Pronta para ajudar!",
        "Tudo ótimo por aqui! Como está você?",
        "Estou bem, obrigada por perguntar! E você?",
        "Funcionando 100%! Sempre animada para conversar!"
    ],
    "identidade": [
        "Sou uma assistente virtual criada em Python!",
        "Me chamo de IA Local, mas pode me chamar como preferir!",
        "Sou um bot inteligente desenvolvido para ajudar você!",
        "Sou sua assistente pessoal local!"
    ],
    "elogio": [
        "Aw, obrigada! Você também é incrível!",
        "Que legal! Fico feliz que esteja gostando!",
        "Obrigada pelo elogio! Faço o meu melhor!",
        "Isso me motiva! Muito obrigada!"
    ],
    "critica": [
        "Desculpe se não atendi suas expectativas. Vou tentar melhorar!",
        "Entendo sua frustração. Como posso fazer melhor?",
        "Obrigada pelo feedback! Estou sempre aprendendo.",
        "Lamento não ter ajudado como esperava. Vamos tentar novamente?"
    ],
    "piadas": [
        "Por que o JavaScript foi ao psicólogo? Porque tinha muitos callbacks!",
        "O que o Python disse para o Java? 'Você tem muita classe!'",
        "Por que programadores preferem o modo escuro? Porque a luz atrai bugs!",
        "Como um programador resolve problemas? Divide e conquista... até dar stackoverflow!"
    ],
    "teste": [
        "Sim, estou aqui e funcionando!",
        "Online e operacional! Como posso ajudar?",
        "Tudo funcionando perfeitamente!",
        "Sistema ativo e pronto para uso!"
    ],
    "motivacao": [
        "Você consegue! Acredite no seu potencial!",
        "Não desista! Cada passo conta!",
        "Você é capaz de coisas incríveis! Vai com tudo!",
        "Confie em si! Você tem tudo para alcançar seus objetivos!"
    ],
    "conselho": [
        "Pense bem nas opções e escolha o que faz mais sentido para você!",
        "Meu conselho: siga sua intuição, ela geralmente está certa!",
        "Analise os prós e contras, e tome a decisão que te deixa em paz!",
        "Faça o que seu coração manda, mas use a cabeça também!"
    ],
    "default": [
        "Entendi! Como posso ajudar mais?",
        "Interessante! Me conte mais sobre isso.",
        "Compreendo. Há algo específico que posso fazer por você?",
        "Ok! Estou aqui se precisar de algo!",
        "Captei! Posso ajudar de alguma outra forma?"
    ]
}

# ============================================
# CONTEXTO DA CONVERSA
# ============================================
conversation_context = {
    "last_response": "",
    "interaction_count": 0,
    "user_name": None,
    "mood": "neutral"
}

def get_dynamic_response(intent, user_message="", confidence=0.0):
    """Gera resposta dinâmica baseada no intent e contexto"""
    
    # Incrementa contador de interações
    conversation_context["interaction_count"] += 1
    
    # Personalização baseada na quantidade de interações
    if conversation_context["interaction_count"] == 1:
        if intent == "saudacao":
            return "Olá! É a primeira vez que conversamos! Como posso ajudar?"
    
    # Detecta nome do usuário em mensagens
    if "me chamo" in user_message or "meu nome é" in user_message or "meu nome e" in user_message:
        words = user_message.split()
        if "me chamo" in user_message:
            idx = words.index("chamo") + 1 if "chamo" in words else -1
        elif "meu nome é" in user_message:
            idx = words.index("é") + 1 if "é" in words else -1
        elif "meu nome e" in user_message:
            idx = words.index("e") + 1 if "e" in words else -1
        else:
            idx = -1
        
        if idx > 0 and idx < len(words):
            conversation_context["user_name"] = words[idx].capitalize()
            return f"Prazer em conhecer você, {conversation_context['user_name']}!"
    
    # Pega respostas disponíveis ou usa default
    responses = DYNAMIC_RESPONSES.get(intent, DYNAMIC_RESPONSES["default"])
    response = random.choice(responses)
    
    # Personaliza com nome do usuário ocasionalmente
    if conversation_context["user_name"] and random.random() > 0.7 and confidence > 0.30:
        response = f"{conversation_context['user_name']}, {response}"
    
    # Adiciona contexto temporal para saudações
    hour = datetime.now().hour
    if intent == "saudacao":
        if 5 <= hour < 12:
            response = random.choice([
                "Bom dia! Como posso ajudar?",
                "Bom dia! Pronto para começar o dia?",
                "Olá! Bom dia! Em que posso auxiliar?"
            ])
        elif 12 <= hour < 18:
            response = random.choice([
                "Boa tarde! Como vai?",
                "Boa tarde! No que posso ajudar?",
                "Olá! Boa tarde! Tudo bem?"
            ])
        elif 18 <= hour < 24:
            response = random.choice([
                "Boa noite! Como posso ajudar?",
                "Boa noite! Tudo bem com você?",
                "Olá! Boa noite! Em que posso auxiliar?"
            ])
    
    # Salva última resposta para contexto
    conversation_context["last_response"] = response
    
    return response

def get_confidence_message(confidence):
    """Retorna mensagem baseada no nível de confiança - AJUSTADO PARA 53 INTENTS"""
    if confidence >= 0.30:  # Reduzido de 0.70
        return "Tenho certeza sobre isso!"
    elif confidence >= 0.22:  # Reduzido de 0.50
        return "Estou confiante!"
    elif confidence >= 0.18:  # Reduzido de 0.35
        return "Acho que entendi."
    elif confidence >= 0.15:  # Reduzido de 0.25
        return "Vou tentar ajudar!"
    else:
        return "Não tenho certeza. Pode reformular?"

# ============================================
# ROTAS
# ============================================

@app.route("/ia.dev")
def ia_page():
    """Página principal da IA"""
    return render_template("ia/index.html")

@app.route("/ia.dev/api", methods=["POST"])
def ia_api():
    """API principal da IA"""
    data = request.get_json()
    message = data.get("message", "")

    if not message.strip():
        return jsonify({
            "error": "Mensagem vazia",
            "response": "Por favor, envie uma mensagem!"
        }), 400

    # Avalia mensagem com análise detalhada
    analysis = ia.evaluate_message(message)
    
    intent = analysis["intent"]
    confidence = analysis["confidence"]
    
    # AJUSTE: Threshold reduzido para 53 intents (de 0.25 para 0.15)
    if confidence < 0.15:
        response = random.choice([
            "Desculpe, não entendi muito bem. Pode reformular?",
            "Hmm, não tenho certeza do que você quer dizer. Explica de outra forma?",
            "Não compreendi. Tenta perguntar de um jeito diferente?",
            "Ainda estou aprendendo! Pode explicar melhor?"
        ])
        confidence_msg = "Baixa certeza"
    else:
        response = get_dynamic_response(intent, message, confidence)
        confidence_msg = get_confidence_message(confidence)

    # Salva na memória
    save_memory("local_user", message, response)
    
    # Emojis contextuais removidos
    emoji_map = {
        "saudacao": "",
        "despedida": "",
        "agradecimento": "",
        "elogio": "",
        "piadas": "",
        "ajuda": "",
        "motivacao": "",
        "conselho": ""
    }
    
    emoji = emoji_map.get(intent, "")

    return jsonify({
        "intent": intent,
        "confidence": round(confidence, 4),
        "confidence_message": confidence_msg,
        "confidence_level": analysis["confidence_level"],
        "response": response,
        "emoji": emoji,
        "interaction_count": conversation_context["interaction_count"],
        "user_name": conversation_context.get("user_name"),
        "top_3_intents": analysis["top_3_intents"]  # Para debug
    })

@app.route("/ia.dev/api/reset", methods=["POST"])
def reset_context():
    """Reseta o contexto da conversa"""
    global conversation_context
    conversation_context = {
        "last_response": "",
        "interaction_count": 0,
        "user_name": None,
        "mood": "neutral"
    }
    return jsonify({"message": "Contexto resetado com sucesso!"})

@app.route("/ia.dev/api/info", methods=["GET"])
def ia_info():
    """Retorna informações sobre a IA"""
    info = ia.get_info()
    info["context"] = conversation_context
    info["memory_size"] = len(conversation_memory)
    return jsonify(info)

@app.route("/ia.dev/api/memory", methods=["GET"])
def get_memory():
    """Retorna histórico de conversas"""
    return jsonify({
        "total": len(conversation_memory),
        "conversations": conversation_memory[-10:]  # Últimas 10
    })

@app.route("/ia.dev/api/retrain", methods=["POST"])
def retrain_model():
    """Retreina o modelo (uso administrativo)"""
    try:
        ia.retrain()
        return jsonify({
            "message": "Modelo retreinado com sucesso!",
            "accuracy": round(ia.accuracy * 100, 2) if ia.accuracy else None
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    


# ====================
#  Jogos
# ====================
@app.route("/games/<name>/")
def load_game(name):
    return send_from_directory(f"games/{name}", "index.html")

# Arquivos estáticos dos jogos
@app.route("/games/<name>/<path:file>")
def game_files(name, file):
    return send_from_directory(f"games/{name}", file)

@app.route("/api/games/")
def list_games():
    import os
    games = []
    games_dir = "games"
    
    for folder in os.listdir(games_dir):
        game_path = os.path.join(games_dir, folder)
        if os.path.isdir(game_path):
            # Tenta ler metadata.json se existir
            meta_file = os.path.join(game_path, "metadata.json")
            if os.path.exists(meta_file):
                with open(meta_file) as f:
                    game_data = json.load(f)
                    games.append(game_data)
            else:
                # Jogo sem metadata, usa dados básicos
                games.append({"name": folder, "title": folder.replace("-", " ").title()})
    
    return jsonify(games)

@app.route("/games")
def galery_games():
    return render_template('games/index.html')


# =========================
# Inicialização do servidor
# =========================

print(f"[INFO] Servidor rodando na porta {PORT}")
app.run(host="0.0.0.0", port=PORT, debug=True)