"""
Configuration loader for the application. Reads `config.json` and exposes
`config` dictionary with helper functions for common config-related tasks.

Modules should import:

from config_loader import config, get, is_allowed_file, get_database_name

"""
from pathlib import Path
import json
import logging

logger = logging.getLogger(__name__)

DEFAULT_CONFIG = {
    "debug": False,
    "port": 80,
    "host": "0.0.0.0",
    "secret_key": "your-secret-key-change-this",
    "jwt_expiration_hours": 24,
    "max_file_size_mb": 100,
    "allowed_extensions": {
        "video": [
            "mp4",
            "avi",
            "mov",
            "wmv",
            "flv",
            "mkv",
            "webm"
        ],
        "document": [
            "pdf",
            "doc",
            "docx",
            "txt",
            "ppt",
            "pptx",
            "xls",
            "xlsx"
        ],
        "image": [
            "jpg",
            "jpeg",
            "png",
            "gif",
            "svg",
            "webp",
            "bmp"
        ]
    },
    "upload_folder": "uploads",
    "database_name": "school_system.db",
    "school_info": {
        "name": "Escola Estadual Dona Indá",
        "admin_email": "dsve367@gmail.com",
        "phone": "35 99756-7963",
        "address": "Minha rua 123",
        "timezone": "America/Sao_Paulo",
        "academic_year": 2025
    }
}

CONFIG_FILE_PATH = Path(__file__).parent / "config.json"


def load_config(path: Path = CONFIG_FILE_PATH):
    config = DEFAULT_CONFIG.copy()
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                # Merge shallow keys: loaded overrides defaults
                config = {**config, **loaded}
    except Exception as e:
        logger.error(f"Failed to load config from {path}: {e}")
    return config


# load at import
config = load_config()


# Helper accessor
def get(key, default=None):
    return config.get(key, default)


# helpers for file uploads
def max_file_size_bytes():
    return get("max_file_size_mb", 100) * 1024 * 1024


def allowed_extensions_flat():
    allowed = []
    for ext_list in get("allowed_extensions", {}).values():
        allowed.extend(ext_list)
    return list(set(allowed))


def is_allowed_file(filename: str) -> bool:
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in allowed_extensions_flat()


def get_upload_folder():
    return get("upload_folder", "uploads")


def get_database_name():
    return get("database_name", "school_system.db")


def get_secret_key():
    return get("secret_key")


def get_host_port_debug():
    return get("host", "0.0.0.0"), get("port", 80), get("debug", False)


def get_school_info():
    return get("school_info", {})
