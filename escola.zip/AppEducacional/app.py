import os
import json
import sqlite3
import hashlib
import jwt
import uuid
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session, send_file
from flask_cors import CORS
from werkzeug.utils import secure_filename
from functools import wraps
import logging
from pathlib import Path
import sys
import io

import time
import requests
import threading

# Set UTF-8 encoding for stdout/stderr
sys.stdout = io.TextIOWrapper(sys.stdout.detach(),
                              encoding='utf-8',
                              errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(),
                              encoding='utf-8',
                              errors='replace')


# Load central config
from config_loader import config, get, is_allowed_file, get_upload_folder, get_database_name, get_secret_key, get_school_info, max_file_size_bytes, get_host_port_debug

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", get_secret_key())
CORS(app)
app.config['SECRET_KEY'] = app.secret_key

# Configuration
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


# Config loaded from `config_loader.py` (module-level `config` dict, and helper `get()`)


class DatabaseManager:
    """Database manager for the educational system"""

    def __init__(self, db_name):
        self.db_name = db_name
        self.init_database()

    def get_connection(self):
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn

    def execute_query(self, query, params=None, fetch=False, fetchone=False):
        """Execute query with proper connection handling"""
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            if fetchone:
                result = cursor.fetchone()
            elif fetch:
                result = cursor.fetchall()
            else:
                result = None

            conn.commit()
            return result
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def query_one(self, query, params=()):
        row = self.execute_query(query, params=params, fetchone=True)
        return dict(row) if row else None

    def init_database(self):
        conn = self.get_connection()
        cursor = conn.cursor()

        # Users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100),
                password_hash VARCHAR(255) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                cpf VARCHAR(20),
                user_type VARCHAR(20) NOT NULL CHECK (user_type IN ('admin', 'teacher', 'student')),
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Ensure CPF column exists in case of older DB versions
        try:
            cursor.execute("PRAGMA table_info(users)")
            existing_cols = [row[1] for row in cursor.fetchall()]
            if 'cpf' not in existing_cols:
                cursor.execute("ALTER TABLE users ADD COLUMN cpf VARCHAR(20);")
        except Exception:
            # Ignore - column may exist or DB doesn't support ALTER (sqlite supports ADD COLUMN)
            pass

        # Classes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS classes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                grade_level VARCHAR(20),
                academic_year INTEGER,
                teacher_id INTEGER,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES users (id)
            )
        """)

        # Subjects table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS subjects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                teacher_id INTEGER,
                class_id INTEGER,
                color VARCHAR(7) DEFAULT '#007bff',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES users (id),
                FOREIGN KEY (class_id) REFERENCES classes (id)
            )
        """)

        # Materials table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS materials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                file_path VARCHAR(500),
                file_type VARCHAR(20),
                file_size INTEGER,
                subject_id INTEGER,
                uploaded_by INTEGER,
                is_public BOOLEAN DEFAULT 0,
                download_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (uploaded_by) REFERENCES users (id)
            )
        """)

        try:
            cursor.execute("PRAGMA table_info(materials)")
            existing_cols = [row[1] for row in cursor.fetchall()]

            if "filename" not in existing_cols:
                cursor.execute("ALTER TABLE materials ADD COLUMN filename VARCHAR(255)")

            if "original_filename" not in existing_cols:
                cursor.execute("ALTER TABLE materials ADD COLUMN original_filename VARCHAR(255)")

        except Exception:
            pass
        
        # Class students table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS class_students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                class_id INTEGER,
                student_id INTEGER,
                enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (class_id) REFERENCES classes (id),
                FOREIGN KEY (student_id) REFERENCES users (id),
                UNIQUE(class_id, student_id)
            )
        """)

        # Assignments table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                subject_id INTEGER,
                teacher_id INTEGER,
                class_id INTEGER,
                due_date TIMESTAMP,
                max_grade INTEGER DEFAULT 100,
                points INTEGER DEFAULT 0,
                assignment_type VARCHAR(50) DEFAULT 'homework',
                instructions TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (teacher_id) REFERENCES users (id),
                FOREIGN KEY (class_id) REFERENCES classes (id)
            )
        """)

        # Assignment submissions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assignment_submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                assignment_id INTEGER,
                student_id INTEGER,
                submission_text TEXT,
                file_path VARCHAR(500),
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                grade FLOAT,
                feedback TEXT,
                graded_by INTEGER,
                graded_at TIMESTAMP,
                FOREIGN KEY (assignment_id) REFERENCES assignments (id),
                FOREIGN KEY (student_id) REFERENCES users (id),
                FOREIGN KEY (graded_by) REFERENCES users (id)
            )
        """)

        # Student progress table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS student_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                subject_id INTEGER,
                material_id INTEGER,
                progress_percentage FLOAT DEFAULT 0,
                time_spent INTEGER DEFAULT 0,
                last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed BOOLEAN DEFAULT 0,
                FOREIGN KEY (student_id) REFERENCES users (id),
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (material_id) REFERENCES materials (id)
            )
        """)

        conn.commit()
        conn.close()

        self.create_default_admin()

    def create_default_admin(self):
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT id FROM users WHERE user_type = 'admin'")
        if cursor.fetchone():
            conn.close()
            return

        admin_password = "admin123"
        password_hash = hashlib.sha256(admin_password.encode()).hexdigest()

        cursor.execute(
            """
            INSERT INTO users (username, email, password_hash, full_name, user_type)
            VALUES (?, ?, ?, ?, ?)
        """, ("admin", "admin@escola.com", password_hash, "Administrador",
              "admin"))

        conn.commit()
        conn.close()

        logger.info(
            "Default admin user created - Login: admin | Password: admin123")


# Initialize managers
db = DatabaseManager(get_database_name())
# Set Flask max content length for uploads using central config
app.config['MAX_CONTENT_LENGTH'] = max_file_size_bytes()
# Ensure upload folder exists
Path(get_upload_folder()).mkdir(parents=True, exist_ok=True)


def row_to_dict(row):
    return dict(row) if row else None


# Authentication decorator
def login_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))

        # Verify user still exists and is active
        user = get_user_by_id(session['user_id'])
        if not user:
            session.clear()
            flash('Your account is no longer valid. Please log in again.',
                  'error')
            return redirect(url_for('login'))

        return f(*args, **kwargs)

    return decorated_function


def admin_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Admin access required', 'error')
            return redirect(url_for('login'))

        # Verify user still exists and is active admin
        user = get_user_by_id(session['user_id'])
        if not user or user['user_type'] != 'admin':
            session.clear()
            flash('Admin access required', 'error')
            return redirect(url_for('login'))

        return f(*args, **kwargs)

    return decorated_function


def teacher_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Not logged in'}), 403

        # Verify user still exists and has proper permissions
        user = get_user_by_id(session['user_id'])
        if not user:
            session.clear()
            return jsonify({
                'success': False,
                'message': 'Invalid session'
            }), 403

        if user['user_type'] not in ('teacher', 'admin'):
            return jsonify({
                'success': False,
                'message': 'Permission denied'
            }), 403

        return f(*args, **kwargs)

    return decorated_function


# Helper functions
def get_user_by_id(user_id):
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ? AND is_active = 1",
                   (user_id, ))
    user = cursor.fetchone()
    conn.close()
    return user


def verify_password(password, password_hash):
    return hashlib.sha256(password.encode()).hexdigest() == password_hash


def allowed_file(filename):
    """Check if file extension is allowed"""
    if '.' not in filename:
        return False

    return is_allowed_file(filename)


def get_file_type(filename):
    """Get file type category based on extension"""
    if '.' not in filename:
        return 'unknown'

    extension = filename.rsplit('.', 1)[1].lower()
    for file_type, extensions in config.get('allowed_extensions', {}).items():
        if extension in extensions:
            return file_type

    return 'unknown'


@app.context_processor
def inject_school_info():
    # Use the centralized school_info from config.json
    return dict(school_info=get_school_info())


# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        user_type = session.get('user_type')
        if user_type == 'admin':
            return redirect(url_for('admin_dashboard'))
        elif user_type == 'teacher':
            return redirect(url_for('teacher_dashboard'))
        elif user_type == 'student':
            return redirect(url_for('student_dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            flash('Username and password are required', 'error')
            return render_template('login.html')

        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM users WHERE username = ? AND is_active = 1",
            (username, ))
        user = cursor.fetchone()
        conn.close()

        if user and verify_password(password, user['password_hash']):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['user_type'] = user['user_type']
            session['full_name'] = user['full_name']

            flash(f'Welcome, {user["full_name"]}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'error')
    
    
       
    if config.get('debug'):
        defalt_user = '<div class="mt-4 text-center"><small class="text-muted"><i data-feather="info" class="me-1"></i>Usuário padrão: admin | Senha: admin123</small></div>'
    else:
        defalt_user = ''

    return render_template('login.html', school_info=config.get('school_info'), defalt_user=defalt_user)


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))


@app.route('/admin')
@admin_required
def admin_dashboard():
    # Get statistics using improved database handling
    result = db.execute_query(
        "SELECT COUNT(*) as count FROM users WHERE user_type = 'student' AND is_active = 1",
        fetchone=True)
    total_students = result['count'] if result else 0

    result = db.execute_query(
        "SELECT COUNT(*) as count FROM users WHERE user_type = 'teacher' AND is_active = 1",
        fetchone=True)
    total_teachers = result['count'] if result else 0

    result = db.execute_query(
        "SELECT COUNT(*) as count FROM classes WHERE is_active = 1",
        fetchone=True)
    total_classes = result['count'] if result else 0

    result = db.execute_query("SELECT COUNT(*) as count FROM materials",
                              fetchone=True)
    total_materials = result['count'] if result else 0

    # Get recent users
    recent_users = db.execute_query("""
        SELECT id, username, full_name, user_type, created_at 
        FROM users 
        WHERE is_active = 1
        ORDER BY created_at DESC 
        LIMIT 5
    """,
                                    fetch=True)

    stats = {
        'total_students': total_students,
        'total_teachers': total_teachers,
        'total_classes': total_classes,
        'total_materials': total_materials
    }

    return render_template('admin_dashboard.html',
                           stats=stats,
                           recent_users=recent_users,
                           school_info=config.get('school_info'))


@app.route('/teacher')
@teacher_required
def teacher_dashboard():
    user_id = session.get('user_id')

    # Get teacher's classes
    classes = db.execute_query("""
        SELECT c.*, COUNT(cs.student_id) as student_count
        FROM classes c
        LEFT JOIN class_students cs ON c.id = cs.class_id AND cs.is_active = 1
        WHERE c.teacher_id = ? AND c.is_active = 1
        GROUP BY c.id
    """, (user_id, ),
                               fetch=True)

    # Get teacher's subjects
    subjects = db.execute_query("""
        SELECT s.*, c.name as class_name
        FROM subjects s
        LEFT JOIN classes c ON s.class_id = c.id
        WHERE s.teacher_id = ? AND s.is_active = 1
    """, (user_id, ),
                                fetch=True)

    # Get teacher's materials
    materials = db.execute_query("""
        SELECT m.*, s.name as subject_name
        FROM materials m
        LEFT JOIN subjects s ON m.subject_id = s.id
        WHERE m.uploaded_by = ?
        ORDER BY m.created_at DESC
        LIMIT 5
    """, (user_id, ),
                                 fetch=True)

    return render_template('teacher_dashboard.html',
                           classes=classes,
                           subjects=subjects,
                           materials=materials,
                           school_info=config.get('school_info'))


@app.route('/student')
@login_required
def student_dashboard():
    user_id = session.get('user_id')
    conn = db.get_connection()
    cursor = conn.cursor()

    # Get student's classes
    cursor.execute(
        """
        SELECT c.*, u.full_name as teacher_name
        FROM classes c
        JOIN class_students cs ON c.id = cs.class_id
        LEFT JOIN users u ON c.teacher_id = u.id
        WHERE cs.student_id = ? AND cs.is_active = 1 AND c.is_active = 1
    """, (user_id, ))
    classes = cursor.fetchall()

    # Get available materials
    cursor.execute(
        """
        SELECT m.*, s.name as subject_name, c.name as class_name
        FROM materials m
        JOIN subjects s ON m.subject_id = s.id
        JOIN classes c ON s.class_id = c.id
        JOIN class_students cs ON c.id = cs.class_id
        WHERE cs.student_id = ? AND cs.is_active = 1
        ORDER BY m.created_at DESC
        LIMIT 10
    """, (user_id, ))
    materials = cursor.fetchall()

    # Get assignments
    cursor.execute(
        """
        SELECT a.*, s.name as subject_name, c.name as class_name
        FROM assignments a
        JOIN subjects s ON a.subject_id = s.id
        JOIN classes c ON a.class_id = c.id
        JOIN class_students cs ON c.id = cs.class_id
        WHERE cs.student_id = ? AND a.is_active = 1
        ORDER BY a.due_date ASC
        LIMIT 5
    """, (user_id, ))
    assignments = cursor.fetchall()

    conn.close()

    return render_template('student_dashboard.html',
                           classes=classes,
                           materials=materials,
                           assignments=assignments,
                           school_info=config.get('school_info'))


@app.route('/users')
@admin_required
def users():
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users ORDER BY created_at DESC")
    all_users = cursor.fetchall()
    conn.close()
    # Use the centralized school_info from config so footer shows full details
    return render_template('users.html',
                           users=all_users,
                           school_info=config.get('school_info'))


@app.route('/classes')
@login_required
def classes():
    user_type = session.get('user_type')
    user_id = session.get('user_id')

    conn = db.get_connection()
    cursor = conn.cursor()

    if user_type == 'admin':
        cursor.execute("""
            SELECT c.*, u.full_name as teacher_name, COUNT(cs.student_id) as student_count
            FROM classes c
            LEFT JOIN users u ON c.teacher_id = u.id
            LEFT JOIN class_students cs ON c.id = cs.class_id AND cs.is_active = 1
            WHERE c.is_active = 1
            GROUP BY c.id
            ORDER BY c.created_at DESC
        """)
    elif user_type == 'teacher':
        cursor.execute(
            """
            SELECT c.*, u.full_name as teacher_name, COUNT(cs.student_id) as student_count
            FROM classes c
            LEFT JOIN users u ON c.teacher_id = u.id
            LEFT JOIN class_students cs ON c.id = cs.class_id AND cs.is_active = 1
            WHERE c.teacher_id = ? AND c.is_active = 1
            GROUP BY c.id
            ORDER BY c.created_at DESC
        """, (user_id, ))
    else:  # student
        cursor.execute(
            """
            SELECT c.*, u.full_name as teacher_name, COUNT(cs2.student_id) as student_count
            FROM classes c
            JOIN class_students cs ON c.id = cs.class_id
            LEFT JOIN users u ON c.teacher_id = u.id
            LEFT JOIN class_students cs2 ON c.id = cs2.class_id AND cs2.is_active = 1
            WHERE cs.student_id = ? AND cs.is_active = 1 AND c.is_active = 1
            GROUP BY c.id
            ORDER BY c.created_at DESC
        """, (user_id, ))

    all_classes = cursor.fetchall()

    # Get all teachers for the form (admin only)
    teachers = []
    if user_type == 'admin':
        cursor.execute(
            "SELECT id, full_name FROM users WHERE user_type = 'teacher' AND is_active = 1"
        )
        teachers = cursor.fetchall()

    conn.close()

    return render_template('classes.html',
                           classes=all_classes,
                           teachers=teachers)


@app.route('/subjects')
@login_required
def subjects():
    user_type = session.get('user_type')
    user_id = session.get('user_id')

    conn = db.get_connection()
    cursor = conn.cursor()

    if user_type == 'admin':
        cursor.execute("""
            SELECT s.*, u.full_name as teacher_name, c.name as class_name
            FROM subjects s
            LEFT JOIN users u ON s.teacher_id = u.id
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.is_active = 1
            ORDER BY s.created_at DESC
        """)
    elif user_type == 'teacher':
        cursor.execute(
            """
            SELECT s.*, u.full_name as teacher_name, c.name as class_name
            FROM subjects s
            LEFT JOIN users u ON s.teacher_id = u.id
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.teacher_id = ? AND s.is_active = 1
            ORDER BY s.created_at DESC
        """, (user_id, ))
    else:  # student
        cursor.execute(
            """
            SELECT s.*, u.full_name as teacher_name, c.name as class_name
            FROM subjects s
            JOIN classes c ON s.class_id = c.id
            JOIN class_students cs ON c.id = cs.class_id
            LEFT JOIN users u ON s.teacher_id = u.id
            WHERE cs.student_id = ? AND cs.is_active = 1 AND s.is_active = 1
            ORDER BY s.created_at DESC
        """, (user_id, ))

    all_subjects = cursor.fetchall()

    # Get teachers and classes for forms
    teachers = []
    classes_list = []
    if user_type in ['admin', 'teacher']:
        cursor.execute(
            "SELECT id, full_name FROM users WHERE user_type = 'teacher' AND is_active = 1"
        )
        teachers = cursor.fetchall()

        if user_type == 'admin':
            cursor.execute("SELECT id, name FROM classes WHERE is_active = 1")
        else:
            cursor.execute(
                "SELECT id, name FROM classes WHERE teacher_id = ? AND is_active = 1",
                (user_id, ))
        classes_list = cursor.fetchall()

    conn.close()

    return render_template('subjects.html',
                           subjects=all_subjects,
                           teachers=teachers,
                           classes=classes_list)


@app.route('/materials')
@login_required
def materials():
    user_type = session.get('user_type')
    user_id = session.get('user_id')

    conn = db.get_connection()
    cursor = conn.cursor()

    if user_type == 'admin':
        cursor.execute("""
            SELECT m.*, s.name as subject_name, u.full_name as uploaded_by_name
            FROM materials m
            LEFT JOIN subjects s ON m.subject_id = s.id
            LEFT JOIN users u ON m.uploaded_by = u.id
            ORDER BY m.created_at DESC
        """)
    elif user_type == 'teacher':
        cursor.execute(
            """
            SELECT m.*, s.name as subject_name, u.full_name as uploaded_by_name
            FROM materials m
            LEFT JOIN subjects s ON m.subject_id = s.id
            LEFT JOIN users u ON m.uploaded_by = u.id
            WHERE m.uploaded_by = ? OR s.teacher_id = ?
            ORDER BY m.created_at DESC
        """, (user_id, user_id))
    else:  # student
        cursor.execute(
            """
            SELECT m.*, s.name as subject_name, u.full_name as uploaded_by_name
            FROM materials m
            JOIN subjects s ON m.subject_id = s.id
            JOIN classes c ON s.class_id = c.id
            JOIN class_students cs ON c.id = cs.class_id
            LEFT JOIN users u ON m.uploaded_by = u.id
            WHERE cs.student_id = ? AND cs.is_active = 1
            ORDER BY m.created_at DESC
        """, (user_id, ))

    all_materials = cursor.fetchall()

    # Get subjects for upload form
    subjects_list = []
    if user_type in ['admin', 'teacher']:
        if user_type == 'admin':
            cursor.execute("SELECT id, name FROM subjects WHERE is_active = 1")
        else:
            cursor.execute(
                "SELECT id, name FROM subjects WHERE teacher_id = ? AND is_active = 1",
                (user_id, ))
        subjects_list = cursor.fetchall()

    conn.close()

    return render_template('materials.html',
                           materials=all_materials,
                           subjects=subjects_list,
                           allowed_extensions=config.get('allowed_extensions'))


@app.route('/assignments')
@login_required
def assignments():
    user_type = session.get('user_type')
    user_id = session.get('user_id')

    conn = db.get_connection()
    cursor = conn.cursor()

    if user_type == 'admin':
        cursor.execute("""
            SELECT a.*, s.name as subject_name, c.name as class_name, u.full_name as teacher_name
            FROM assignments a
            LEFT JOIN subjects s ON a.subject_id = s.id
            LEFT JOIN classes c ON a.class_id = c.id
            LEFT JOIN users u ON a.teacher_id = u.id
            WHERE a.is_active = 1
            ORDER BY a.due_date ASC
        """)
    elif user_type == 'teacher':
        cursor.execute("""
            SELECT a.*, s.name as subject_name, c.name as class_name, u.full_name as teacher_name
            FROM assignments a
            LEFT JOIN subjects s ON a.subject_id = s.id
            LEFT JOIN classes c ON a.class_id = c.id
            LEFT JOIN users u ON a.teacher_id = u.id
            WHERE a.teacher_id = ? AND a.is_active = 1
            ORDER BY a.due_date ASC
        """, (user_id,))
    else:  # student
        cursor.execute("""
            SELECT a.*, s.name as subject_name, c.name as class_name, u.full_name as teacher_name,
                   asub.id as submission_id, asub.grade, asub.submitted_at
            FROM assignments a
            JOIN subjects s ON a.subject_id = s.id
            JOIN classes c ON a.class_id = c.id
            JOIN class_students cs ON c.id = cs.class_id
            LEFT JOIN users u ON a.teacher_id = u.id
            LEFT JOIN assignment_submissions asub ON a.id = asub.assignment_id AND asub.student_id = ?
            WHERE cs.student_id = ? AND cs.is_active = 1 AND a.is_active = 1
            ORDER BY a.due_date ASC
        """, (user_id, user_id))

    all_assignments = cursor.fetchall()

    # adiciona flag de atraso
    now = datetime.now()
    processed_assignments = []
    for a in all_assignments:
        a = dict(a)  # transforma Row em dict (caso esteja usando sqlite3.Row)
        try:
            due_date = datetime.strptime(a['due_date'], "%Y-%m-%d %H:%M:%S")
            a['is_overdue'] = due_date < now
        except Exception:
            a['is_overdue'] = False  # fallback se a data vier nula ou mal formatada
        processed_assignments.append(a)

    # Get subjects and classes for forms
    subjects_list = []
    classes_list = []
    if user_type in ['admin', 'teacher']:
        if user_type == 'admin':
            cursor.execute("SELECT id, name FROM subjects WHERE is_active = 1")
            subjects_list = cursor.fetchall()
            cursor.execute("SELECT id, name FROM classes WHERE is_active = 1")
            classes_list = cursor.fetchall()
        else:
            cursor.execute("SELECT id, name FROM subjects WHERE teacher_id = ? AND is_active = 1", (user_id,))
            subjects_list = cursor.fetchall()
            cursor.execute("SELECT id, name FROM classes WHERE teacher_id = ? AND is_active = 1", (user_id,))
            classes_list = cursor.fetchall()

    conn.close()

    return render_template(
        'assignments.html',
        assignments=processed_assignments,
        subjects=subjects_list,
        classes=classes_list
    )

@app.route('/progress')
@login_required
def progress():
    user_type = session.get('user_type')
    user_id = session.get('user_id')

    conn = db.get_connection()
    cursor = conn.cursor()

    if user_type == 'student':
        # Get student's own progress
        cursor.execute(
            """
            SELECT sp.*, s.name as subject_name, m.title as material_title,
                   c.name as class_name
            FROM student_progress sp
            JOIN subjects s ON sp.subject_id = s.id
            JOIN materials m ON sp.material_id = m.id
            JOIN classes c ON s.class_id = c.id
            WHERE sp.student_id = ?
            ORDER BY sp.last_accessed DESC
        """, (user_id, ))
        progress_data = cursor.fetchall()
    else:
        # Teachers and admins can see all progress
        query_params = []
        base_query = """
            SELECT sp.*, s.name as subject_name, m.title as material_title,
                   c.name as class_name, u.full_name as student_name
            FROM student_progress sp
            JOIN subjects s ON sp.subject_id = s.id
            JOIN materials m ON sp.material_id = m.id
            JOIN classes c ON s.class_id = c.id
            JOIN users u ON sp.student_id = u.id
        """

        if user_type == 'teacher':
            base_query += " WHERE s.teacher_id = ?"
            query_params.append(user_id)

        base_query += " ORDER BY sp.last_accessed DESC LIMIT 50"

        if query_params:
            cursor.execute(base_query, query_params)
        else:
            cursor.execute(base_query)
        progress_data = cursor.fetchall()

    conn.close()

    return render_template('progress.html', progress_data=progress_data)


# API endpoints for AJAX operations
@app.route('/api/users', methods=['POST'])
@admin_required
def create_user():
    try:
        data = request.get_json()

        username = data.get('username')
        email = data.get('email', '')  # Email is now optional
        password = data.get('password')
        full_name = data.get('full_name')
        user_type = data.get('user_type')
        cpf = data.get('cpf') if data.get('user_type') == 'student' else None

        if not all([username, password, full_name, user_type]):
            return jsonify({
                'success':
                False,
                'message':
                'Username, password, full name and user type are required'
            }), 400

        # If a student, CPF is required
        if user_type == 'student' and not cpf:
            return jsonify({'success': False, 'message': 'CPF é obrigatório para usuários do tipo aluno'}), 400

        # Prevent duplicate CPF registration
        if cpf:
            exists_cpf = db.execute_query("SELECT id FROM users WHERE cpf = ?", (cpf,), fetchone=True)
            if exists_cpf:
                return jsonify({'success': False, 'message': 'CPF já cadastrado para outro usuário'}), 400

        password_hash = hashlib.sha256(password.encode()).hexdigest()

        db.execute_query(
            """
            INSERT INTO users (username, email, password_hash, full_name, user_type, cpf)
            VALUES (?, ?, ?, ?, ?, ?)
            """, (username, email if email else None, password_hash, full_name,
                  user_type, cpf))

        return jsonify({
            'success': True,
            'message': 'User created successfully'
        })

    except sqlite3.IntegrityError as e:
        return jsonify({
            'success': False,
            'message': 'Username already exists'
        }), 400
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


# Adicione estas rotas ao seu app.py (após a rota POST /api/assignments)

@app.route('/api/assignments/<int:assignment_id>', methods=['GET'])
@login_required
def get_assignment(assignment_id):
    """Get assignment details"""
    try:
        user_type = session.get('user_type')
        user_id = session.get('user_id')

        # Get assignment with related data
        assignment = db.execute_query("""
            SELECT a.*, s.name as subject_name, c.name as class_name, u.full_name as teacher_name
            FROM assignments a
            LEFT JOIN subjects s ON a.subject_id = s.id
            LEFT JOIN classes c ON a.class_id = c.id
            LEFT JOIN users u ON a.teacher_id = u.id
            WHERE a.id = ?
        """, (assignment_id,), fetchone=True)

        if not assignment:
            return jsonify({'success': False, 'message': 'Assignment not found'}), 404

        assignment_dict = dict(assignment)

        # Check permissions
        if user_type == 'student':
            # Verify student is enrolled in the class
            enrolled = db.execute_query(
                "SELECT 1 FROM class_students WHERE student_id = ? AND class_id = ? AND is_active = 1",
                (user_id, assignment_dict['class_id']),
                fetchone=True
            )
            if not enrolled:
                return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        elif user_type == 'teacher':
            # Verify teacher owns the assignment
            if assignment_dict['teacher_id'] != user_id:
                return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        return jsonify({
            'success': True,
            'assignment': assignment_dict
        })

    except Exception as e:
        logger.error(f"Error getting assignment: {e}")
        return jsonify({'success': False, 'message': 'Internal server error'}), 500


@app.route('/api/assignments/<int:assignment_id>', methods=['PUT'])
@login_required
def update_assignment(assignment_id):
    """Update assignment"""
    try:
        user_type = session.get('user_type')
        user_id = session.get('user_id')

        # Check permissions
        if user_type not in ['admin', 'teacher']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        # Verify assignment exists and user has permission
        assignment = db.execute_query(
            "SELECT teacher_id FROM assignments WHERE id = ?",
            (assignment_id,),
            fetchone=True
        )

        if not assignment:
            return jsonify({'success': False, 'message': 'Assignment not found'}), 404

        assignment_dict = dict(assignment)

        # Teachers can only edit their own assignments
        if user_type == 'teacher' and assignment_dict['teacher_id'] != user_id:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        data = request.get_json(force=True, silent=True) or {}
        
        title = data.get('title')
        description = data.get('description', '')
        subject_id = data.get('subject_id')
        class_id = data.get('class_id')
        due_date = data.get('due_date')
        max_grade = data.get('max_grade', 100)
        instructions = data.get('instructions', '')

        if not all([title, subject_id, class_id, due_date]):
            return jsonify({
                'success': False,
                'message': 'Title, subject, class, and due date are required'
            }), 400

        # Convert IDs to int
        try:
            subject_id = int(subject_id)
            class_id = int(class_id)
            max_grade = int(max_grade)
        except ValueError:
            return jsonify({
                'success': False,
                'message': 'IDs and grades must be integers'
            }), 400

        # Update assignment
        db.execute_query("""
            UPDATE assignments 
            SET title = ?, description = ?, subject_id = ?, class_id = ?, 
                due_date = ?, max_grade = ?, instructions = ?
            WHERE id = ?
        """, (title, description, subject_id, class_id, due_date, max_grade, instructions, assignment_id))

        return jsonify({
            'success': True,
            'message': 'Assignment updated successfully'
        }), 200

    except Exception as e:
        logger.error(f"Error updating assignment: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/assignments/<int:assignment_id>', methods=['DELETE'])
@login_required
def delete_assignment(assignment_id):
    """Delete (deactivate) assignment"""
    try:
        user_type = session.get('user_type')
        user_id = session.get('user_id')

        # Check permissions
        if user_type not in ['admin', 'teacher']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        # Verify assignment exists and user has permission
        assignment = db.execute_query(
            "SELECT teacher_id FROM assignments WHERE id = ?",
            (assignment_id,),
            fetchone=True
        )

        if not assignment:
            return jsonify({'success': False, 'message': 'Assignment not found'}), 404

        assignment_dict = dict(assignment)

        # Teachers can only delete their own assignments
        if user_type == 'teacher' and assignment_dict['teacher_id'] != user_id:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        # Soft delete - set is_active to 0
        db.execute_query(
            "UPDATE assignments SET is_active = 0 WHERE id = ?",
            (assignment_id,)
        )

        return jsonify({
            'success': True,
            'message': 'Assignment deleted successfully'
        }), 200

    except Exception as e:
        logger.error(f"Error deleting assignment: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/assignments/<int:assignment_id>/submissions', methods=['GET'])
@login_required
def get_assignment_submissions(assignment_id):
    """Get all submissions for an assignment (teacher/admin only)"""
    try:
        user_type = session.get('user_type')
        user_id = session.get('user_id')

        # Check permissions
        if user_type not in ['admin', 'teacher']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        # Verify assignment exists and user has permission
        assignment = db.execute_query(
            "SELECT teacher_id, class_id FROM assignments WHERE id = ?",
            (assignment_id,),
            fetchone=True
        )

        if not assignment:
            return jsonify({'success': False, 'message': 'Assignment not found'}), 404

        assignment_dict = dict(assignment)

        # Teachers can only view submissions for their own assignments
        if user_type == 'teacher' and assignment_dict['teacher_id'] != user_id:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        # Get all submissions
        submissions = db.execute_query("""
            SELECT asub.*, u.full_name as student_name, u.username
            FROM assignment_submissions asub
            JOIN users u ON asub.student_id = u.id
            WHERE asub.assignment_id = ?
            ORDER BY asub.submitted_at DESC
        """, (assignment_id,), fetch=True)

        # Get students enrolled in the class who haven't submitted
        not_submitted = db.execute_query("""
            SELECT u.id, u.full_name, u.username
            FROM users u
            JOIN class_students cs ON u.id = cs.student_id
            WHERE cs.class_id = ? AND cs.is_active = 1
            AND u.id NOT IN (
                SELECT student_id FROM assignment_submissions WHERE assignment_id = ?
            )
            ORDER BY u.full_name
        """, (assignment_dict['class_id'], assignment_id), fetch=True)

        return jsonify({
            'success': True,
            'submissions': [dict(sub) for sub in submissions],
            'not_submitted': [dict(student) for student in not_submitted]
        })

    except Exception as e:
        logger.error(f"Error getting submissions: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/classes', methods=['POST'])
@login_required
def create_class():
    try:
        user_type = session.get('user_type')
        if user_type not in ['admin', 'teacher']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        data = request.get_json()

        name = data.get('name')
        description = data.get('description', '')
        grade_level = data.get('grade_level')
        teacher_id = data.get('teacher_id')
        academic_year = data.get(
            'academic_year',
            config.get('school_info', {}).get('academic_year', 2025))

        if not all([name, grade_level, teacher_id]):
            return jsonify({
                'success':
                False,
                'message':
                'Name, grade level, and teacher are required'
            }), 400

        db.execute_query(
            """
            INSERT INTO classes (name, description, grade_level, teacher_id, academic_year)
            VALUES (?, ?, ?, ?, ?)
            """, (name, description, grade_level, teacher_id, academic_year))

        return jsonify({
            'success': True,
            'message': 'Class created successfully'
        })

    except Exception as e:
        logger.error(f"Error creating class: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/subjects', methods=['POST'])
@login_required
def create_subject():
    try:
        user_type = session.get('user_type')
        if user_type not in ['admin', 'teacher']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        data = request.get_json()

        name = data.get('name')
        description = data.get('description', '')
        teacher_id = data.get('teacher_id')
        class_id = data.get('class_id')
        color = data.get('color', '#007bff')

        if not all([name, teacher_id, class_id]):
            return jsonify({
                'success': False,
                'message': 'Name, teacher, and class are required'
            }), 400

        db.execute_query(
            """
            INSERT INTO subjects (name, description, teacher_id, class_id, color)
            VALUES (?, ?, ?, ?, ?)
            """, (name, description, teacher_id, class_id, color))

        return jsonify({
            'success': True,
            'message': 'Subject created successfully'
        })

    except Exception as e:
        logger.error(f"Error creating subject: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/assignments', methods=['POST'])
@login_required
def create_assignment():
    try:
        user_type = session.get('user_type')
        user_id = session.get('user_id')

        # Verifica permissão
        if user_type not in ('admin', 'teacher'):
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        data = request.get_json(force=True, silent=True) or {}
        title = data.get('title')
        description = data.get('description', '')
        subject_id = data.get('subject_id')
        class_id = data.get('class_id')
        due_date = data.get('due_date')
        max_grade = data.get('max_grade', 100)

        # Validação de campos obrigatórios
        if not all([title, subject_id, class_id, due_date]):
            return jsonify({
                'success':
                False,
                'message':
                'Title, subject, class, and due date are required'
            }), 400

        # Converte IDs para int (evita erro de tipo no banco)
        try:
            subject_id = int(subject_id)
            class_id = int(class_id)
            max_grade = int(max_grade)
        except ValueError:
            return jsonify({
                'success': False,
                'message': 'IDs and grades must be integers'
            }), 400

        # Se for admin, opcionalmente permitir escolher teacher_id
        teacher_id = user_id
        if user_type == 'admin' and 'teacher_id' in data:
            teacher_id = int(data['teacher_id'])

        # Insere no banco
        db.execute_query(
            """
            INSERT INTO assignments (title, description, subject_id, class_id, teacher_id, due_date, max_grade)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (title, description, subject_id, class_id, teacher_id,
                  due_date, max_grade))

        return jsonify({
            'success': True,
            'message': 'Assignment created successfully'
        }), 201

    except Exception as e:
        import traceback
        traceback.print_exc()  # Mostra o erro real no console
        logger.error(f"Error creating assignment: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/assignments/submit', methods=['POST'])
@login_required
def submit_assignment():
    try:
        user_id = session.get('user_id')
        data = request.form or request.get_json() or {}

        assignment_id = data.get('assignment_id')
        submission_text = data.get('submission_text', '')

        file = request.files.get('file')

        if not assignment_id:
            return jsonify({'success': False, 'message': 'assignment_id is required'}), 400

        assignment_id = int(assignment_id)

        file_path = None
        if file:
            filename = secure_filename(file.filename)
            unique_name = f"{uuid.uuid4()}_{filename}"
            upload_folder = get_upload_folder()
            file_path = os.path.join(upload_folder, unique_name)
            file.save(file_path)

        db.execute_query("""
            INSERT INTO assignment_submissions (assignment_id, student_id, submission_text, file_path)
            VALUES (?, ?, ?, ?)
        """, (assignment_id, user_id, submission_text, file_path))

        return jsonify({'success': True, 'message': 'Submission sent successfully'}), 201

    except Exception as e:
        logger.error(f"Error submitting assignment: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/materials', methods=['POST'])
@login_required
def upload_material():
    try:
        user_type = session.get('user_type')
        if user_type not in ['admin', 'teacher']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        # Coleta dos dados do formulário
        title = request.form.get('title')
        description = request.form.get('description', '')
        subject_id = request.form.get(
            'subject_id') or None  # Se vazio, vira None
        is_public = request.form.get(
            'is_public') == 'on'  # Checkbox envia "on"

        # Validação de título
        if not title:
            return jsonify({
                'success': False,
                'message': 'Title is required'
            }), 400

        # Verifica se foi enviado arquivo
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No file selected'
            }), 400

        file = request.files['file']

        if not file or not file.filename or file.filename.strip() == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            }), 400

        # Verifica extensão do arquivo
        if file and allowed_file(file.filename):
            filename = secure_filename(f"{uuid.uuid4()}_{file.filename}")
            upload_path = os.path.join(config.get('upload_folder', 'uploads'),
                                       filename)

            os.makedirs(os.path.dirname(upload_path), exist_ok=True)
            file.save(upload_path)

            file_size = os.path.getsize(upload_path)
            file_type = get_file_type(filename)
            user_id = session.get('user_id')

            # Insere no banco, subject_id pode ser None
            db.execute_query(
                """
                INSERT INTO materials (title, description, file_path, original_filename, file_type, file_size, subject_id, uploaded_by, is_public)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (title, description, upload_path, file.filename,
                      file_type, file_size, subject_id, user_id, is_public))

            return jsonify({
                'success': True,
                'message': 'Material uploaded successfully'
            })

        return jsonify({
            'success': False,
            'message': 'File type not allowed'
        }), 400

    except Exception as e:
        logger.error(f"Error uploading material: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route("/api/materials/<int:material_id>", methods=["GET"])
@login_required
def get_material(material_id):
    try:
        material = db.execute_query("""
            SELECT id, title, description, file_type, file_size, subject_id, uploaded_by, created_at, download_count
            FROM materials
            WHERE id = ?
            """, (material_id, ),
                                    fetchone=True)

        if not material:
            return jsonify({"error": "Material não encontrado"}), 404

        material_dict = dict(material)
        return jsonify(material_dict)
    except Exception as e:
        logger.error(f"Error getting material: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/materials/<int:material_id>", methods=["PUT"])
@login_required
def update_material(material_id):
    """Atualiza título e descrição do material."""
    try:
        user_type = session.get("user_type")
        user_id = session.get("user_id")

        # Só admin ou professor que enviou o material pode editar
        material = db.execute_query(
            "SELECT uploaded_by FROM materials WHERE id = ?", (material_id, ),
            fetchone=True)
        if not material:
            return jsonify({"error": "Material não encontrado"}), 404
        material_dict = dict(material)
        if user_type != "admin" and material_dict["uploaded_by"] != user_id:
            return jsonify({"error": "Não autorizado"}), 403

        data = request.get_json()
        title = data.get("title")
        description = data.get("description", "")

        if not title:
            return jsonify({"error": "Título é obrigatório"}), 400

        db.execute_query(
            "UPDATE materials SET title = ?, description = ? WHERE id = ?",
            (title, description, material_id))
        return jsonify({
            "success": True,
            "message": "Material atualizado com sucesso"
        })
    except Exception as e:
        logger.error(f"Error updating material: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/materials/<int:material_id>", methods=["DELETE"])
@login_required
def delete_material(material_id):
    """Remove um material do banco e opcionalmente do disco."""
    try:
        user_type = session.get("user_type")
        user_id = session.get("user_id")

        material = db.execute_query(
            "SELECT uploaded_by, file_path FROM materials WHERE id = ?",
            (material_id, ),
            fetchone=True)
        if not material:
            return jsonify({"error": "Material não encontrado"}), 404
        material_dict = dict(material)
        if user_type != "admin" and material_dict["uploaded_by"] != user_id:
            return jsonify({"error": "Não autorizado"}), 403

        # Remove do banco
        db.execute_query("DELETE FROM materials WHERE id = ?", (material_id, ))

        # Opcional: remover arquivo físico
        try:
            if os.path.exists(material_dict["file_path"]):
                os.remove(material_dict["file_path"])
        except Exception as e:
            logger.warning(f"Erro ao excluir arquivo físico: {e}")

        return jsonify({
            "success": True,
            "message": "Material excluído com sucesso"
        })
    except Exception as e:
        logger.error(f"Error deleting material: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/materials/<int:material_id>/download")
@login_required
def download_material(material_id):
    try:
        user_type = session.get("user_type")
        user_id = session.get("user_id")

        # Get material and check permissions
        material = db.execute_query("""
            SELECT m.file_path, m.original_filename, m.uploaded_by, m.is_public, m.subject_id,
                   s.teacher_id, s.class_id
            FROM materials m 
            LEFT JOIN subjects s ON m.subject_id = s.id
            WHERE m.id = ?
            """, (material_id, ),
                                    fetchone=True)

        if not material:
            return jsonify({"error": "Material não encontrado"}), 404

        material_dict = dict(material)

        # Check access permissions
        can_access = False

        if user_type == 'admin' or material_dict['is_public']:
            can_access = True
        elif user_type == 'teacher':
            # Teacher can access their own materials or materials from their subjects
            if material_dict['uploaded_by'] == user_id or material_dict[
                    'teacher_id'] == user_id:
                can_access = True
        elif user_type == 'student':
            # Student can access materials from classes they're enrolled in
            if material_dict['class_id']:
                enrolled = db.execute_query(
                    "SELECT 1 FROM class_students WHERE student_id = ? AND class_id = ? AND is_active = 1",
                    (user_id, material_dict['class_id']),
                    fetchone=True)
                if enrolled:
                    can_access = True

        if not can_access:
            return jsonify({"error": "Acesso negado a este material"}), 403

        # Check if file exists
        if not os.path.exists(material_dict["file_path"]):
            return jsonify({"error":
                            "Arquivo não encontrado no servidor"}), 404

        # Increment download count
        db.execute_query(
            "UPDATE materials SET download_count = download_count + 1 WHERE id = ?",
            (material_id, ))

        return send_file(material_dict["file_path"],
                         as_attachment=True,
                         download_name=material_dict["original_filename"])
    except Exception as e:
        logger.error(f"Error downloading material: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/materials/<int:material_id>/view")
@login_required
def view_material(material_id):
    """View/preview material in browser"""
    try:
        user_type = session.get("user_type")
        user_id = session.get("user_id")

        # Get material and check permissions (same logic as download)
        material = db.execute_query("""
            SELECT m.file_path, m.original_filename, m.uploaded_by, m.is_public, m.subject_id,
                   s.teacher_id, s.class_id, m.file_type
            FROM materials m 
            LEFT JOIN subjects s ON m.subject_id = s.id
            WHERE m.id = ?
            """, (material_id, ),
                                    fetchone=True)

        if not material:
            return jsonify({"error": "Material não encontrado"}), 404

        material_dict = dict(material)

        # Check access permissions
        can_access = False

        if user_type == 'admin' or material_dict['is_public']:
            can_access = True
        elif user_type == 'teacher':
            if material_dict['uploaded_by'] == user_id or material_dict[
                    'teacher_id'] == user_id:
                can_access = True
        elif user_type == 'student':
            if material_dict['class_id']:
                enrolled = db.execute_query(
                    "SELECT 1 FROM class_students WHERE student_id = ? AND class_id = ? AND is_active = 1",
                    (user_id, material_dict['class_id']),
                    fetchone=True)
                if enrolled:
                    can_access = True

        if not can_access:
            return jsonify({"error": "Acesso negado a este material"}), 403

        # Check if file exists
        if not os.path.exists(material_dict["file_path"]):
            return jsonify({"error":
                            "Arquivo não encontrado no servidor"}), 404

        # Serve file for viewing (not as attachment)
        return send_file(material_dict["file_path"])
    except Exception as e:
        logger.error(f"Error viewing material: {e}")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/api/enroll-student', methods=['POST'])
@teacher_required
def enroll_student():
    """API endpoint for teachers/admins to enroll students in their classes"""
    try:
        data = request.get_json(force=True, silent=True) or {}
        user_id = session.get('user_id')
        student_id = data.get('student_id')
        class_id = data.get('class_id')

        logger.debug(f"Enroll request by user {user_id}: class={class_id}, student={student_id}")

        if not all([student_id, class_id]):
            return jsonify({
                'success': False,
                'message': 'Student and class are required'
            }), 400

        # Descobre o usuário logado
        user = get_user_by_id(user_id)

        # Se for admin, pode matricular em qualquer turma ativa
        if user['user_type'] == 'admin':
            class_check = db.execute_query(
                "SELECT id FROM classes WHERE id = ? AND is_active = 1",
                (class_id,),
                fetchone=True)
        else:
            # Professor só pode em suas próprias turmas
            class_check = db.execute_query(
                "SELECT id FROM classes WHERE id = ? AND teacher_id = ? AND is_active = 1",
                (class_id, user_id),
                fetchone=True)

        if not class_check:
            return jsonify({
                'success': False,
                'message': 'Class not found or unauthorized'
            }), 403

        # Verifica se o aluno existe
        student_check = db.execute_query(
            "SELECT id FROM users WHERE id = ? AND user_type = 'student' AND is_active = 1",
            (student_id, ),
            fetchone=True)

        if not student_check:
            return jsonify({
                'success': False,
                'message': 'Student not found'
            }), 404

        # Verifica se já está matriculado
        existing_enrollment = db.execute_query(
            "SELECT id FROM class_students WHERE class_id = ? AND student_id = ? AND is_active = 1",
            (class_id, student_id),
            fetchone=True)

        if existing_enrollment:
            return jsonify({
                'success': False,
                'message': 'Student is already enrolled in this class'
            }), 400

        # Faz a matrícula: não especificar a coluna de data para usar o DEFAULT (enrollment_date)
        db.execute_query(
            """
            INSERT INTO class_students (class_id, student_id)
            VALUES (?, ?)
            """, (class_id, student_id))

        return jsonify({
            'success': True,
            'message': 'Student enrolled successfully'
        })

    except Exception as e:
        logger.error(f"Error enrolling student: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/students', methods=['GET'])
@login_required
def get_students():
    """Get list of students for enrollment"""
    try:
        user_type = session.get('user_type')
        if user_type not in ['admin', 'teacher']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        students = db.execute_query(
            "SELECT id, full_name, username, email FROM users WHERE user_type = 'student' AND is_active = 1 ORDER BY full_name",
            fetch=True)

        return jsonify({
            'success': True,
            'students': [dict(student) for student in students]
        })

    except Exception as e:
        logger.error(f"Error getting students: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/class-students/<int:class_id>', methods=['GET'])
@login_required
def get_class_students(class_id):
    """Get students enrolled in a specific class"""
    try:
        user_type = session.get('user_type')
        user_id = session.get('user_id')

        # Check permissions
        if user_type == 'teacher':
            # Verify teacher owns the class
            class_check = db.execute_query(
                "SELECT id FROM classes WHERE id = ? AND teacher_id = ? AND is_active = 1",
                (class_id, user_id),
                fetchone=True)
            if not class_check:
                return jsonify({
                    'success': False,
                    'message': 'Unauthorized'
                }), 403
        elif user_type != 'admin':
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        students = db.execute_query("""
            SELECT u.id, u.full_name, u.username, u.email, cs.enrollment_date
            FROM users u
            JOIN class_students cs ON u.id = cs.student_id
            WHERE cs.class_id = ? AND cs.is_active = 1
            ORDER BY u.full_name
            """, (class_id, ),
                                    fetch=True)

        return jsonify({
            'success': True,
            'students': [dict(student) for student in students]
        })

    except Exception as e:
        logger.error(f"Error getting class students: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/remove-student', methods=['POST'])
@teacher_required
def remove_student():
    """Remove student from class"""
    try:
        data = request.get_json()
        teacher_id = session.get('user_id')
        student_id = data.get('student_id')
        class_id = data.get('class_id')

        if not all([student_id, class_id]):
            return jsonify({
                'success': False,
                'message': 'Student and class are required'
            }), 400

        # Verify teacher owns the class
        class_check = db.execute_query(
            "SELECT id FROM classes WHERE id = ? AND teacher_id = ? AND is_active = 1",
            (class_id, teacher_id),
            fetchone=True)

        if not class_check:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        # Remove student from class
        db.execute_query(
            "UPDATE class_students SET is_active = 0 WHERE class_id = ? AND student_id = ?",
            (class_id, student_id))

        return jsonify({
            'success': True,
            'message': 'Student removed successfully'
        })

    except Exception as e:
        logger.error(f"Error removing student: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/users/reset-password', methods=['POST'])
@admin_required
def reset_user_password():
    """Reset user password to a random one"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')

        if not user_id:
            return jsonify({
                'success': False,
                'message': 'User ID is required'
            }), 400

        # Generate new random password
        import secrets
        import string
        new_password = ''.join(
            secrets.choice(string.ascii_letters + string.digits)
            for _ in range(8))
        password_hash = hashlib.sha256(new_password.encode()).hexdigest()

        # Update password in database
        db.execute_query("UPDATE users SET password_hash = ? WHERE id = ?",
                         (password_hash, user_id))

        return jsonify({
            'success': True,
            'message': 'Senha resetada com sucesso',
            'new_password': new_password
        })

    except Exception as e:
        logger.error(f"Error resetting password: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/users/toggle-status', methods=['POST'])
@admin_required
def toggle_user_status():
    """Toggle user active/inactive status"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        is_active = data.get('is_active')

        if user_id is None or is_active is None:
            return jsonify({
                'success': False,
                'message': 'User ID and status are required'
            }), 400

        # Don't allow deactivating the current admin user
        current_user_id = session.get('user_id')
        if user_id == current_user_id and not is_active:
            return jsonify({
                'success': False,
                'message': 'You cannot deactivate your own account'
            }), 400

        # Update user status
        db.execute_query("UPDATE users SET is_active = ? WHERE id = ?",
                         (is_active, user_id))

        return jsonify({
            'success': True,
            'message': 'Status do usuário atualizado com sucesso'
        })

    except Exception as e:
        logger.error(f"Error toggling user status: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error'
        }), 500


@app.route('/api/users/<int:user_id>', methods=['PUT'])
@admin_required
def update_user(user_id):
    """Update user's full name and email. CPF is not editable via platform."""
    try:
        data = request.get_json()
        full_name = data.get('full_name')
        email = data.get('email', None)

        if not full_name:
            return jsonify({'success': False, 'message': 'Full name is required'}), 400

        db.execute_query("UPDATE users SET full_name = ?, email = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                         (full_name, email if email else None, user_id))

        return jsonify({'success': True, 'message': 'User updated successfully'})
    except Exception as e:
        logger.error(f"Error updating user: {e}")
        return jsonify({'success': False, 'message': 'Internal server error'}), 500


if __name__ == '__main__':
    host, port, debug = get_host_port_debug()
    app.run(debug=debug, host=host, port=port)
