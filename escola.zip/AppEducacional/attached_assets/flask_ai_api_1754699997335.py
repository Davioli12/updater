import os
import json
import sqlite3
import hashlib
import jwt
import uuid
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from werkzeug.utils import secure_filename
from functools import wraps
import logging
from pathlib import Path
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding='utf-8', errors='replace')


app = Flask(__name__)
CORS(app)

# Configuração de logs
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ConfigManager:
    """Gerenciador de configurações do servidor"""
    
    def __init__(self, config_file='config.json'):
        self.config_file = config_file
        self.default_config = {
            "debug": True,
            "port": 5000,
            "host": "0.0.0.0",
            "secret_key": "your-secret-key-change-this",
            "jwt_expiration_hours": 24,
            "max_file_size_mb": 100,
            "allowed_extensions": {
                "video": ["mp4", "avi", "mov", "wmv", "flv"],
                "document": ["pdf", "doc", "docx", "txt", "ppt", "pptx"],
                "image": ["jpg", "jpeg", "png", "gif", "svg"]
            },
            "upload_folder": "uploads",
            "database_name": "school_system.db",
            "ai_service": {
                "enabled": False,
                "provider": "free_service",
                "api_key": "",
                "model": "gpt-3.5-turbo"
            },
            "school_info": {
                "name": "Escola Digital",
                "admin_email": "admin@escola.com",
                "timezone": "America/Sao_Paulo"
            }
        }
        self.load_config()
    
    def load_config(self):
        """Carrega configurações do arquivo ou cria padrão"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    # Merge com configuração padrão
                    self.config = {**self.default_config, **loaded_config}
            else:
                self.config = self.default_config.copy()
                self.save_config()
        except Exception as e:
            logger.error(f"Erro ao carregar config: {e}")
            self.config = self.default_config.copy()
    
    def save_config(self):
        """Salva configurações no arquivo"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Erro ao salvar config: {e}")
    
    def get(self, key, default=None):
        """Obtém valor de configuração"""
        return self.config.get(key, default)
    
    def set(self, key, value):
        """Define valor de configuração"""
        self.config[key] = value
        self.save_config()

class DatabaseManager:
    """Gerenciador do banco de dados"""
    
    def __init__(self, db_name):
        self.db_name = db_name
        self.init_database()
    
    def get_connection(self):
        """Obtém conexão com o banco"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """Inicializa tabelas do banco de dados"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Tabela de usuários (admin, professores, alunos)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                user_type VARCHAR(20) NOT NULL CHECK (user_type IN ('admin', 'teacher', 'student')),
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabela de classes/turmas
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS classes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                grade_level VARCHAR(20),
                academic_year INTEGER,
                teacher_id INTEGER,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES users (id)
            )
        """)
        
        # Tabela de matérias/disciplinas
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS subjects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                teacher_id INTEGER,
                class_id INTEGER,
                color VARCHAR(7) DEFAULT '#007bff',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES users (id),
                FOREIGN KEY (class_id) REFERENCES classes (id)
            )
        """)
        
        # Tabela de materiais (PDFs, vídeos, etc.)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS materials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                file_path VARCHAR(500),
                file_type VARCHAR(20),
                file_size INTEGER,
                subject_id INTEGER,
                uploaded_by INTEGER,
                is_public BOOLEAN DEFAULT 0,
                download_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (uploaded_by) REFERENCES users (id)
            )
        """)
        
        # Tabela de alunos em classes
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS class_students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                class_id INTEGER,
                student_id INTEGER,
                enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (class_id) REFERENCES classes (id),
                FOREIGN KEY (student_id) REFERENCES users (id),
                UNIQUE(class_id, student_id)
            )
        """)
        
        # Tabela de progresso dos estudantes
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS student_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                subject_id INTEGER,
                material_id INTEGER,
                progress_percentage FLOAT DEFAULT 0,
                time_spent INTEGER DEFAULT 0,
                last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed BOOLEAN DEFAULT 0,
                FOREIGN KEY (student_id) REFERENCES users (id),
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (material_id) REFERENCES materials (id)
            )
        """)
        
        # Tabela de planos de estudo
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS study_plans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(200) NOT NULL,
                description TEXT,
                teacher_id INTEGER,
                class_id INTEGER,
                start_date DATE,
                end_date DATE,
                plan_data TEXT, -- JSON com estrutura do plano
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES users (id),
                FOREIGN KEY (class_id) REFERENCES classes (id)
            )
        """)
        
        # Tabela de atividades/tarefas
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                subject_id INTEGER,
                teacher_id INTEGER,
                class_id INTEGER,
                due_date TIMESTAMP,
                points INTEGER DEFAULT 0,
                assignment_type VARCHAR(50) DEFAULT 'homework',
                instructions TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (teacher_id) REFERENCES users (id),
                FOREIGN KEY (class_id) REFERENCES classes (id)
            )
        """)
        
        # Tabela de submissões de atividades
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assignment_submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                assignment_id INTEGER,
                student_id INTEGER,
                submission_text TEXT,
                file_path VARCHAR(500),
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                grade FLOAT,
                feedback TEXT,
                graded_by INTEGER,
                graded_at TIMESTAMP,
                FOREIGN KEY (assignment_id) REFERENCES assignments (id),
                FOREIGN KEY (student_id) REFERENCES users (id),
                FOREIGN KEY (graded_by) REFERENCES users (id)
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Criar usuário admin padrão
        self.create_default_admin()
    
    def create_default_admin(self):
        """Cria usuário administrador padrão"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Verificar se já existe admin
        cursor.execute("SELECT id FROM users WHERE user_type = 'admin'")
        if cursor.fetchone():
            conn.close()
            return
        
        # Criar admin padrão
        admin_password = "admin123"
        password_hash = hashlib.sha256(admin_password.encode()).hexdigest()
        
        cursor.execute("""
            INSERT INTO users (username, email, password_hash, full_name, user_type)
            VALUES (?, ?, ?, ?, ?)
        """, ("admin", "admin@escola.com", password_hash, "Administrador", "admin"))
        
        conn.commit()
        conn.close()
        
        logger.info("Usuário admin criado - Login: admin | Senha: admin123")

class AIService:
    """Serviço de IA (preparado para integração futura)"""
    
    def __init__(self, config):
        self.enabled = config.get('ai_service', {}).get('enabled', False)
        self.provider = config.get('ai_service', {}).get('provider', 'free_service')
        self.api_key = config.get('ai_service', {}).get('api_key', '')
        
        if config.get('debug'):
            logger.info(f"AI Service - Enabled: {self.enabled}, Provider: {self.provider}")
    
    def is_available(self):
        """Verifica se o serviço de IA está disponível"""
        return self.enabled and self.api_key
    
    def generate_study_plan(self, subject, grade_level, duration_weeks=4):
        """Gera plano de estudos (mock para agora)"""
        if not self.is_available():
            return self._mock_study_plan(subject, grade_level, duration_weeks)
        
        # TODO: Implementar integração com IA real
        return self._mock_study_plan(subject, grade_level, duration_weeks)
    
    def _mock_study_plan(self, subject, grade_level, duration_weeks):
        """Plano de estudos mock"""
        return {
            "subject": subject,
            "grade_level": grade_level,
            "duration_weeks": duration_weeks,
            "weekly_goals": [
                f"Semana {i+1}: Fundamentos de {subject}" for i in range(duration_weeks)
            ],
            "resources": ["Vídeo-aulas", "Exercícios práticos", "Materiais de leitura"],
            "assessment": "Avaliação contínua com exercícios semanais"
        }
    
    def analyze_text(self, text):
        """Analisa texto (preparado para IA futura)"""
        if not self.is_available():
            return {
                "summary": text[:200] + "..." if len(text) > 200 else text,
                "difficulty": "médio",
                "topics": ["tópico geral"],
                "ai_enabled": False
            }
        
        # TODO: Implementar análise real com IA
        return {"message": "IA não implementada ainda", "ai_enabled": False}

# Instâncias globais
config = ConfigManager()
db_manager = DatabaseManager(config.get('database_name'))
ai_service = AIService(config.config)

# Configurar Flask
app.config['SECRET_KEY'] = config.get('secret_key')
app.config['MAX_CONTENT_LENGTH'] = config.get('max_file_size_mb') * 1024 * 1024

# Criar pasta de uploads
os.makedirs(config.get('upload_folder'), exist_ok=True)

# Decorador para autenticação JWT
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'error': 'Token de acesso necessário'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user_id = data['user_id']
            current_user_type = data['user_type']
            
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expirado'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token inválido'}), 401
        
        return f(current_user_id, current_user_type, *args, **kwargs)
    
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(current_user_id, current_user_type, *args, **kwargs):
        if current_user_type != 'admin':
            return jsonify({'error': 'Acesso negado - Apenas administradores'}), 403
        return f(current_user_id, current_user_type, *args, **kwargs)
    return decorated

def teacher_required(f):
    @wraps(f)
    def decorated(current_user_id, current_user_type, *args, **kwargs):
        if current_user_type not in ['admin', 'teacher']:
            return jsonify({'error': 'Acesso negado - Apenas professores'}), 403
        return f(current_user_id, current_user_type, *args, **kwargs)
    return decorated

# ROTAS DA API

@app.route('/api/health', methods=['GET'])
def health_check():
    """Verifica status da API"""
    return jsonify({
        "status": "OK",
        "message": "API Educacional funcionando!",
        "version": "2.0.0",
        "ai_enabled": ai_service.is_available(),
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/config', methods=['GET'])
@token_required
@admin_required
def get_config(current_user_id, current_user_type):
    """Obtém configurações do sistema (apenas admin)"""
    safe_config = config.config.copy()
    # Remover informações sensíveis
    safe_config.pop('secret_key', None)
    if 'ai_service' in safe_config:
        safe_config['ai_service'].pop('api_key', None)
    
    return jsonify(safe_config)

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Autenticação de usuário"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username e password obrigatórios'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, username, email, full_name, user_type, is_active, password_hash
            FROM users WHERE username = ? OR email = ?
        """, (username, username))
        
        user = cursor.fetchone()
        conn.close()
        
        if not user:
            return jsonify({'error': 'Usuário não encontrado'}), 404
        
        if not user['is_active']:
            return jsonify({'error': 'Usuário desativado'}), 403
        
        # Verificar senha
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        if password_hash != user['password_hash']:
            return jsonify({'error': 'Senha incorreta'}), 401
        
        # Gerar token JWT
        token_payload = {
            'user_id': user['id'],
            'user_type': user['user_type'],
            'exp': datetime.utcnow() + timedelta(hours=config.get('jwt_expiration_hours'))
        }
        
        token = jwt.encode(token_payload, app.config['SECRET_KEY'], algorithm='HS256')
        
        return jsonify({
            'token': token,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'full_name': user['full_name'],
                'user_type': user['user_type']
            }
        })
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro no login: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/users', methods=['POST'])
@token_required
@admin_required
def create_user(current_user_id, current_user_type):
    """Criar novo usuário (apenas admin)"""
    try:
        data = request.get_json()
        required_fields = ['username', 'email', 'password', 'full_name', 'user_type']
        
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        if data['user_type'] not in ['admin', 'teacher', 'student']:
            return jsonify({'error': 'Tipo de usuário inválido'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Verificar se usuário já existe
        cursor.execute("SELECT id FROM users WHERE username = ? OR email = ?",
                      (data['username'], data['email']))
        if cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Username ou email já existe'}), 409
        
        # Criar usuário
        password_hash = hashlib.sha256(data['password'].encode()).hexdigest()
        cursor.execute("""
            INSERT INTO users (username, email, password_hash, full_name, user_type)
            VALUES (?, ?, ?, ?, ?)
        """, (data['username'], data['email'], password_hash, 
              data['full_name'], data['user_type']))
        
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Usuário criado: {data['username']} ({data['user_type']})")
        
        return jsonify({
            'message': 'Usuário criado com sucesso',
            'user_id': user_id
        }), 201
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao criar usuário: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/classes', methods=['POST'])
@token_required
@teacher_required
def create_class(current_user_id, current_user_type):
    """Criar nova classe/turma"""
    try:
        data = request.get_json()
        required_fields = ['name', 'grade_level', 'academic_year']
        
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO classes (name, description, grade_level, academic_year, teacher_id)
            VALUES (?, ?, ?, ?, ?)
        """, (data['name'], data.get('description', ''), 
              data['grade_level'], data['academic_year'], current_user_id))
        
        class_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Classe criada: {data['name']} por usuário {current_user_id}")
        
        return jsonify({
            'message': 'Classe criada com sucesso',
            'class_id': class_id
        }), 201
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao criar classe: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/subjects', methods=['POST'])
@token_required
@teacher_required
def create_subject(current_user_id, current_user_type):
    """Criar nova matéria/disciplina"""
    try:
        data = request.get_json()
        required_fields = ['name', 'class_id']
        
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Verificar se o professor tem acesso à classe
        if current_user_type != 'admin':
            cursor.execute("SELECT id FROM classes WHERE id = ? AND teacher_id = ?",
                          (data['class_id'], current_user_id))
            if not cursor.fetchone():
                conn.close()
                return jsonify({'error': 'Acesso negado à essa classe'}), 403
        
        cursor.execute("""
            INSERT INTO subjects (name, description, teacher_id, class_id, color)
            VALUES (?, ?, ?, ?, ?)
        """, (data['name'], data.get('description', ''), current_user_id,
              data['class_id'], data.get('color', '#007bff')))
        
        subject_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Matéria criada: {data['name']} por usuário {current_user_id}")
        
        return jsonify({
            'message': 'Matéria criada com sucesso',
            'subject_id': subject_id
        }), 201
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao criar matéria: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/materials/upload', methods=['POST'])
@token_required
@teacher_required
def upload_material(current_user_id, current_user_type):
    """Upload de material (PDF, vídeo, etc.)"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
        
        # Dados do formulário
        title = request.form.get('title')
        description = request.form.get('description', '')
        subject_id = request.form.get('subject_id')
        is_public = request.form.get('is_public', 'false').lower() == 'true'
        
        if not title or not subject_id:
            return jsonify({'error': 'Título e matéria são obrigatórios'}), 400
        
        # Verificar extensão do arquivo
        allowed_extensions = []
        for ext_list in config.get('allowed_extensions').values():
            allowed_extensions.extend(ext_list)
        
        file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        if file_ext not in allowed_extensions:
            return jsonify({'error': f'Tipo de arquivo não permitido: {file_ext}'}), 400
        
        # Verificar acesso à matéria
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        if current_user_type != 'admin':
            cursor.execute("SELECT id FROM subjects WHERE id = ? AND teacher_id = ?",
                          (subject_id, current_user_id))
            if not cursor.fetchone():
                conn.close()
                return jsonify({'error': 'Acesso negado à essa matéria'}), 403
        
        # Salvar arquivo
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        file_path = os.path.join(config.get('upload_folder'), unique_filename)
        
        file.save(file_path)
        file_size = os.path.getsize(file_path)
        
        # Determinar tipo do arquivo
        file_type = 'document'
        for type_name, extensions in config.get('allowed_extensions').items():
            if file_ext in extensions:
                file_type = type_name
                break
        
        # Salvar no banco
        cursor.execute("""
            INSERT INTO materials (title, description, file_path, file_type, 
                                 file_size, subject_id, uploaded_by, is_public)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (title, description, file_path, file_type, 
              file_size, subject_id, current_user_id, is_public))
        
        material_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Material enviado: {title} por usuário {current_user_id}")
        
        return jsonify({
            'message': 'Material enviado com sucesso',
            'material_id': material_id,
            'file_size': file_size
        }), 201
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao enviar material: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/dashboard/stats', methods=['GET'])
@token_required
def get_dashboard_stats(current_user_id, current_user_type):
    """Obtém estatísticas para o dashboard"""
    try:
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        stats = {}
        
        if current_user_type == 'admin':
            # Stats para admin
            cursor.execute("SELECT COUNT(*) FROM users WHERE user_type = 'teacher'")
            stats['total_teachers'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM users WHERE user_type = 'student'")
            stats['total_students'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM classes WHERE is_active = 1")
            stats['total_classes'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM subjects WHERE is_active = 1")
            stats['total_subjects'] = cursor.fetchone()[0]
            
        elif current_user_type == 'teacher':
            # Stats para professor
            cursor.execute("SELECT COUNT(*) FROM classes WHERE teacher_id = ? AND is_active = 1",
                          (current_user_id,))
            stats['my_classes'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM subjects WHERE teacher_id = ? AND is_active = 1",
                          (current_user_id,))
            stats['my_subjects'] = cursor.fetchone()[0]
            
            cursor.execute("""
                SELECT COUNT(DISTINCT cs.student_id) 
                FROM class_students cs
                JOIN classes c ON c.id = cs.class_id
                WHERE c.teacher_id = ? AND cs.is_active = 1
            """, (current_user_id,))
            stats['my_students'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM materials WHERE uploaded_by = ?",
                          (current_user_id,))
            stats['my_materials'] = cursor.fetchone()[0]
            
        elif current_user_type == 'student':
            # Stats para estudante
            cursor.execute("""
                SELECT COUNT(*) FROM class_students 
                WHERE student_id = ? AND is_active = 1
            """, (current_user_id,))
            stats['enrolled_classes'] = cursor.fetchone()[0]
            
            cursor.execute("""
                SELECT COUNT(DISTINCT s.id) 
                FROM subjects s
                JOIN classes c ON c.id = s.class_id
                JOIN class_students cs ON cs.class_id = c.id
                WHERE cs.student_id = ? AND cs.is_active = 1
            """, (current_user_id,))
            stats['available_subjects'] = cursor.fetchone()[0]
            
            cursor.execute("""
                SELECT AVG(progress_percentage) 
                FROM student_progress 
                WHERE student_id = ?
            """, (current_user_id,))
            avg_progress = cursor.fetchone()[0]
            stats['average_progress'] = round(avg_progress or 0, 1)
        
        conn.close()
        
        return jsonify({
            'stats': stats,
            'user_type': current_user_type,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao obter stats do dashboard: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/classes/<int:class_id>/students', methods=['POST'])
@token_required
@teacher_required
def add_student_to_class(current_user_id, current_user_type, class_id):
    """Adicionar estudante à classe"""
    try:
        data = request.get_json()
        student_id = data.get('student_id')
        
        if not student_id:
            return jsonify({'error': 'ID do estudante é obrigatório'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Verificar se o professor tem acesso à classe
        if current_user_type != 'admin':
            cursor.execute("SELECT id FROM classes WHERE id = ? AND teacher_id = ?",
                          (class_id, current_user_id))
            if not cursor.fetchone():
                conn.close()
                return jsonify({'error': 'Acesso negado à essa classe'}), 403
        
        # Verificar se o estudante existe e é do tipo student
        cursor.execute("SELECT id FROM users WHERE id = ? AND user_type = 'student'",
                      (student_id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Estudante não encontrado'}), 404
        
        # Adicionar à classe
        cursor.execute("""
            INSERT OR REPLACE INTO class_students (class_id, student_id, is_active)
            VALUES (?, ?, 1)
        """, (class_id, student_id))
        
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Estudante {student_id} adicionado à classe {class_id}")
        
        return jsonify({'message': 'Estudante adicionado à classe com sucesso'}), 201
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao adicionar estudante à classe: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/assignments', methods=['POST'])
@token_required
@teacher_required
def create_assignment(current_user_id, current_user_type):
    """Criar nova atividade/tarefa"""
    try:
        data = request.get_json()
        required_fields = ['title', 'subject_id', 'class_id', 'due_date']
        
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Verificar acesso à matéria e classe
        if current_user_type != 'admin':
            cursor.execute("""
                SELECT s.id FROM subjects s
                JOIN classes c ON c.id = s.class_id
                WHERE s.id = ? AND c.id = ? AND s.teacher_id = ?
            """, (data['subject_id'], data['class_id'], current_user_id))
            if not cursor.fetchone():
                conn.close()
                return jsonify({'error': 'Acesso negado à essa matéria ou classe'}), 403
        
        cursor.execute("""
            INSERT INTO assignments (title, description, subject_id, teacher_id, 
                                   class_id, due_date, points, assignment_type, instructions)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (data['title'], data.get('description', ''), data['subject_id'],
              current_user_id, data['class_id'], data['due_date'],
              data.get('points', 0), data.get('assignment_type', 'homework'),
              data.get('instructions', '')))
        
        assignment_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Atividade criada: {data['title']} por usuário {current_user_id}")
        
        return jsonify({
            'message': 'Atividade criada com sucesso',
            'assignment_id': assignment_id
        }), 201
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao criar atividade: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/study-plans', methods=['POST'])
@token_required
@teacher_required
def create_study_plan(current_user_id, current_user_type):
    """Criar plano de estudos"""
    try:
        data = request.get_json()
        required_fields = ['name', 'class_id', 'start_date', 'end_date']
        
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Verificar acesso à classe
        if current_user_type != 'admin':
            cursor.execute("SELECT id FROM classes WHERE id = ? AND teacher_id = ?",
                          (data['class_id'], current_user_id))
            if not cursor.fetchone():
                conn.close()
                return jsonify({'error': 'Acesso negado à essa classe'}), 403
        
        # Gerar plano usando IA (se disponível) ou template
        plan_data = data.get('plan_data')
        if not plan_data:
            # Usar IA para gerar plano básico
            cursor.execute("SELECT name, grade_level FROM classes WHERE id = ?", (data['class_id'],))
            class_info = cursor.fetchone()
            
            ai_plan = ai_service.generate_study_plan(
                subject=data.get('subject', 'Geral'),
                grade_level=class_info['grade_level'] if class_info else 'Médio',
                duration_weeks=4
            )
            plan_data = json.dumps(ai_plan, ensure_ascii=False)
        else:
            plan_data = json.dumps(plan_data, ensure_ascii=False)
        
        cursor.execute("""
            INSERT INTO study_plans (name, description, teacher_id, class_id, 
                                   start_date, end_date, plan_data)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (data['name'], data.get('description', ''), current_user_id,
              data['class_id'], data['start_date'], data['end_date'], plan_data))
        
        plan_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Plano de estudos criado: {data['name']} por usuário {current_user_id}")
        
        return jsonify({
            'message': 'Plano de estudos criado com sucesso',
            'plan_id': plan_id,
            'ai_generated': not data.get('plan_data')
        }), 201
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao criar plano de estudos: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/materials/<int:material_id>/download', methods=['GET'])
@token_required
def download_material(current_user_id, current_user_type, material_id):
    """Download de material"""
    try:
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Buscar material
        cursor.execute("""
            SELECT m.*, s.name as subject_name, c.name as class_name
            FROM materials m
            JOIN subjects s ON s.id = m.subject_id
            JOIN classes c ON c.id = s.class_id
            WHERE m.id = ?
        """, (material_id,))
        
        material = cursor.fetchone()
        if not material:
            conn.close()
            return jsonify({'error': 'Material não encontrado'}), 404
        
        # Verificar acesso
        can_access = False
        
        if current_user_type == 'admin' or material['is_public']:
            can_access = True
        elif current_user_type == 'teacher':
            # Professor pode acessar seus próprios materiais
            if material['uploaded_by'] == current_user_id:
                can_access = True
        elif current_user_type == 'student':
            # Estudante pode acessar materiais das classes em que está matriculado
            cursor.execute("""
                SELECT 1 FROM class_students cs
                JOIN subjects s ON s.class_id = cs.class_id
                WHERE cs.student_id = ? AND s.id = ? AND cs.is_active = 1
            """, (current_user_id, material['subject_id']))
            if cursor.fetchone():
                can_access = True
        
        if not can_access:
            conn.close()
            return jsonify({'error': 'Acesso negado a este material'}), 403
        
        # Incrementar contador de downloads
        cursor.execute("UPDATE materials SET download_count = download_count + 1 WHERE id = ?",
                      (material_id,))
        conn.commit()
        conn.close()
        
        # Verificar se arquivo existe
        if not os.path.exists(material['file_path']):
            return jsonify({'error': 'Arquivo não encontrado no servidor'}), 404
        
        if config.get('debug'):
            logger.info(f"Download do material {material_id} por usuário {current_user_id}")
        
        return send_file(
            material['file_path'],
            as_attachment=True,
            download_name=material['title'] + '.' + material['file_path'].split('.')[-1]
        )
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro no download do material: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/student/progress', methods=['POST'])
@token_required
def update_student_progress(current_user_id, current_user_type):
    """Atualizar progresso do estudante"""
    try:
        if current_user_type != 'student':
            return jsonify({'error': 'Apenas estudantes podem atualizar progresso'}), 403
        
        data = request.get_json()
        required_fields = ['subject_id', 'material_id', 'progress_percentage']
        
        for field in required_fields:
            if data.get(field) is None:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Verificar se estudante tem acesso ao material
        cursor.execute("""
            SELECT 1 FROM class_students cs
            JOIN subjects s ON s.class_id = cs.class_id
            JOIN materials m ON m.subject_id = s.id
            WHERE cs.student_id = ? AND s.id = ? AND m.id = ? AND cs.is_active = 1
        """, (current_user_id, data['subject_id'], data['material_id']))
        
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Acesso negado a este material'}), 403
        
        # Atualizar ou inserir progresso
        cursor.execute("""
            INSERT OR REPLACE INTO student_progress 
            (student_id, subject_id, material_id, progress_percentage, 
             time_spent, completed, last_accessed)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (current_user_id, data['subject_id'], data['material_id'],
              min(100, max(0, data['progress_percentage'])),
              data.get('time_spent', 0),
              data['progress_percentage'] >= 100))
        
        conn.commit()
        conn.close()
        
        if config.get('debug'):
            logger.info(f"Progresso atualizado: usuário {current_user_id}, material {data['material_id']}")
        
        return jsonify({'message': 'Progresso atualizado com sucesso'})
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao atualizar progresso: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/ai/analyze-text', methods=['POST'])
@token_required
def ai_analyze_text(current_user_id, current_user_type):
    """Análise de texto usando IA"""
    try:
        data = request.get_json()
        text = data.get('text')
        
        if not text:
            return jsonify({'error': 'Texto é obrigatório'}), 400
        
        analysis = ai_service.analyze_text(text)
        
        return jsonify({
            'analysis': analysis,
            'ai_available': ai_service.is_available()
        })
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro na análise de texto: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/reports/class/<int:class_id>/progress', methods=['GET'])
@token_required
@teacher_required
def get_class_progress_report(current_user_id, current_user_type, class_id):
    """Relatório de progresso da classe"""
    try:
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        # Verificar acesso à classe
        if current_user_type != 'admin':
            cursor.execute("SELECT id FROM classes WHERE id = ? AND teacher_id = ?",
                          (class_id, current_user_id))
            if not cursor.fetchone():
                conn.close()
                return jsonify({'error': 'Acesso negado à essa classe'}), 403
        
        # Buscar progresso dos estudantes
        cursor.execute("""
            SELECT 
                u.id as student_id,
                u.full_name as student_name,
                s.name as subject_name,
                AVG(sp.progress_percentage) as avg_progress,
                COUNT(sp.id) as materials_accessed,
                MAX(sp.last_accessed) as last_activity
            FROM users u
            JOIN class_students cs ON cs.student_id = u.id
            JOIN subjects s ON s.class_id = cs.class_id
            LEFT JOIN student_progress sp ON sp.student_id = u.id AND sp.subject_id = s.id
            WHERE cs.class_id = ? AND cs.is_active = 1
            GROUP BY u.id, s.id
            ORDER BY u.full_name, s.name
        """, (class_id,))
        
        progress_data = cursor.fetchall()
        
        # Organizar dados por estudante
        students_progress = {}
        for row in progress_data:
            student_id = row['student_id']
            if student_id not in students_progress:
                students_progress[student_id] = {
                    'student_name': row['student_name'],
                    'subjects': [],
                    'overall_progress': 0
                }
            
            students_progress[student_id]['subjects'].append({
                'subject_name': row['subject_name'],
                'avg_progress': round(row['avg_progress'] or 0, 1),
                'materials_accessed': row['materials_accessed'],
                'last_activity': row['last_activity']
            })
        
        # Calcular progresso geral de cada estudante
        for student_data in students_progress.values():
            if student_data['subjects']:
                total_progress = sum(s['avg_progress'] for s in student_data['subjects'])
                student_data['overall_progress'] = round(total_progress / len(student_data['subjects']), 1)
        
        conn.close()
        
        return jsonify({
            'class_id': class_id,
            'students_progress': students_progress,
            'generated_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro ao gerar relatório de progresso: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.route('/api/search', methods=['GET'])
@token_required
def search_content(current_user_id, current_user_type):
    """Pesquisar conteúdo (materiais, classes, etc.)"""
    try:
        query = request.args.get('q', '').strip()
        content_type = request.args.get('type', 'all')  # all, materials, classes, subjects
        
        if not query or len(query) < 2:
            return jsonify({'error': 'Consulta deve ter pelo menos 2 caracteres'}), 400
        
        conn = db_manager.get_connection()
        cursor = conn.cursor()
        
        results = {'materials': [], 'classes': [], 'subjects': []}
        
        if content_type in ['all', 'materials']:
            # Buscar materiais
            if current_user_type == 'student':
                cursor.execute("""
                    SELECT DISTINCT m.id, m.title, m.description, m.file_type,
                           s.name as subject_name, c.name as class_name
                    FROM materials m
                    JOIN subjects s ON s.id = m.subject_id
                    JOIN classes c ON c.id = s.class_id
                    JOIN class_students cs ON cs.class_id = c.id
                    WHERE cs.student_id = ? AND cs.is_active = 1
                    AND (m.title LIKE ? OR m.description LIKE ?)
                    AND (m.is_public = 1 OR s.teacher_id = ?)
                    ORDER BY m.title
                    LIMIT 20
                """, (current_user_id, f'%{query}%', f'%{query}%', current_user_id))
            else:
                cursor.execute("""
                    SELECT m.id, m.title, m.description, m.file_type,
                           s.name as subject_name, c.name as class_name
                    FROM materials m
                    JOIN subjects s ON s.id = m.subject_id
                    JOIN classes c ON c.id = s.class_id
                    WHERE (m.title LIKE ? OR m.description LIKE ?)
                    AND (? = 'admin' OR m.uploaded_by = ? OR m.is_public = 1)
                    ORDER BY m.title
                    LIMIT 20
                """, (f'%{query}%', f'%{query}%', current_user_type, current_user_id))
            
            results['materials'] = [dict(row) for row in cursor.fetchall()]
        
        if content_type in ['all', 'classes'] and current_user_type in ['admin', 'teacher']:
            # Buscar classes
            if current_user_type == 'admin':
                cursor.execute("""
                    SELECT c.id, c.name, c.description, c.grade_level,
                           u.full_name as teacher_name
                    FROM classes c
                    LEFT JOIN users u ON u.id = c.teacher_id
                    WHERE (c.name LIKE ? OR c.description LIKE ?)
                    AND c.is_active = 1
                    ORDER BY c.name
                    LIMIT 20
                """, (f'%{query}%', f'%{query}%'))
            else:
                cursor.execute("""
                    SELECT c.id, c.name, c.description, c.grade_level,
                           u.full_name as teacher_name
                    FROM classes c
                    LEFT JOIN users u ON u.id = c.teacher_id
                    WHERE c.teacher_id = ?
                    AND (c.name LIKE ? OR c.description LIKE ?)
                    AND c.is_active = 1
                    ORDER BY c.name
                    LIMIT 20
                """, (current_user_id, f'%{query}%', f'%{query}%'))
            
            results['classes'] = [dict(row) for row in cursor.fetchall()]
        
        if content_type in ['all', 'subjects']:
            # Buscar matérias
            if current_user_type == 'student':
                cursor.execute("""
                    SELECT DISTINCT s.id, s.name, s.description, s.color,
                           c.name as class_name, u.full_name as teacher_name
                    FROM subjects s
                    JOIN classes c ON c.id = s.class_id
                    JOIN users u ON u.id = s.teacher_id
                    JOIN class_students cs ON cs.class_id = c.id
                    WHERE cs.student_id = ? AND cs.is_active = 1
                    AND (s.name LIKE ? OR s.description LIKE ?)
                    AND s.is_active = 1
                    ORDER BY s.name
                    LIMIT 20
                """, (current_user_id, f'%{query}%', f'%{query}%'))
            else:
                cursor.execute("""
                    SELECT s.id, s.name, s.description, s.color,
                           c.name as class_name, u.full_name as teacher_name
                    FROM subjects s
                    JOIN classes c ON c.id = s.class_id
                    JOIN users u ON u.id = s.teacher_id
                    WHERE (s.name LIKE ? OR s.description LIKE ?)
                    AND (? = 'admin' OR s.teacher_id = ?)
                    AND s.is_active = 1
                    ORDER BY s.name
                    LIMIT 20
                """, (f'%{query}%', f'%{query}%', current_user_type, current_user_id))
            
            results['subjects'] = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({
            'query': query,
            'results': results,
            'total_results': sum(len(v) for v in results.values())
        })
        
    except Exception as e:
        if config.get('debug'):
            logger.error(f"Erro na pesquisa: {e}")
        return jsonify({'error': 'Erro interno do servidor'}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint não encontrado'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Erro interno do servidor'}), 500

if __name__ == '__main__':
    # Criar diretórios necessários
    Path(config.get('upload_folder')).mkdir(exist_ok=True)
    
    # Log de inicialização
    logger.info("🚀 Iniciando Servidor Backend API Educacional v2.0")
    logger.info("="*60)
    logger.info("📋 CONFIGURAÇÕES:")
    logger.info(f"   • Host: {config.get('host')}:{config.get('port')}")
    logger.info(f"   • Debug: {config.get('debug')}")
    logger.info(f"   • Banco: {config.get('database_name')}")
    logger.info(f"   • Upload: {config.get('upload_folder')}")
    logger.info(f"   • IA Habilitada: {ai_service.is_available()}")
    logger.info("="*60)
    logger.info("🔗 ENDPOINTS PRINCIPAIS:")
    logger.info("   AUTENTICAÇÃO:")
    logger.info("   • POST   /api/auth/login")
    logger.info("   USUÁRIOS:")
    logger.info("   • POST   /api/users")
    logger.info("   CLASSES:")
    logger.info("   • POST   /api/classes")
    logger.info("   • POST   /api/classes/{id}/students")
    logger.info("   MATÉRIAS:")
    logger.info("   • POST   /api/subjects")
    logger.info("   MATERIAIS:")
    logger.info("   • POST   /api/materials/upload")
    logger.info("   • GET    /api/materials/{id}/download")
    logger.info("   ATIVIDADES:")
    logger.info("   • POST   /api/assignments")
    logger.info("   PLANOS DE ESTUDO:")
    logger.info("   • POST   /api/study-plans")
    logger.info("   DASHBOARD:")
    logger.info("   • GET    /api/dashboard/stats")
    logger.info("   RELATÓRIOS:")
    logger.info("   • GET    /api/reports/class/{id}/progress")
    logger.info("   UTILIDADES:")
    logger.info("   • GET    /api/search")
    logger.info("   • POST   /api/ai/analyze-text")
    logger.info("   • POST   /api/student/progress")
    logger.info("   • GET    /api/health")
    logger.info("="*60)
    
    if config.get('debug'):
        logger.info("🔧 MODO DEBUG ATIVADO - Logs detalhados habilitados")
        logger.info(f"📁 Arquivo de config: {config.config_file}")
    
    logger.info("✅ Servidor pronto para conexões!")
    
    app.run(
        debug=config.get('debug'),
        host=config.get('host'),
        port=config.get('port')
    )