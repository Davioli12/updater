#!/usr/bin/env python3
# Script de inicialização do Sistema Educacional
# Gerado automaticamente pelo setup

import sys
import os
from pathlib import Path

# Adicionar diretório atual ao path
sys.path.insert(0, str(Path(__file__).parent))

try:
    from flask_ai_api import app, config, logger
    
    if __name__ == '__main__':
        logger.info("Iniciando Sistema Educacional...")
        logger.info(f"Diretório: {Path(__file__).parent}")
        logger.info(f"Acesso: http://{config.get('host')}:{config.get('port')}")
        
        app.run(
            debug=config.get('debug'),
            host=config.get('host'),
            port=config.get('port')
        )
        
except ImportError as e:
    print(f"❌ Erro ao importar: {e}")
    print("📋 Certifique-se de que flask_ai_api.py está no mesmo diretório")
    sys.exit(1)
except Exception as e:
    print(f"❌ Erro ao iniciar servidor: {e}")
    sys.exit(1)
