/**
 * Educational System - Main JavaScript Application
 */

// Global application object
const EduApp = {
    // Configuration
    config: {
        apiUrl: '/api',
        refreshInterval: 30000,
        maxFileSize: 100 * 1024 * 1024, // 100MB
        allowedFileTypes: ['pdf', 'doc', 'docx', 'txt', 'ppt', 'pptx', 'mp4', 'avi', 'mov', 'jpg', 'png', 'gif']
    },

    // Initialize application
    init: function() {
        this.bindEvents();
        this.initializeComponents();
        this.setupAutoRefresh();
        console.log('Educational System initialized');
    },

    // Bind global event listeners
    bindEvents: function() {
        // Handle form submissions
        document.addEventListener('submit', this.handleFormSubmit.bind(this));
        
        // Handle file uploads
        document.addEventListener('change', this.handleFileChange.bind(this));
        
        // Handle search inputs
        document.addEventListener('input', this.handleSearchInput.bind(this));
        
        // Handle responsive navigation
        window.addEventListener('resize', this.handleResize.bind(this));
        
        // Handle keyboard shortcuts
        document.addEventListener('keydown', this.handleKeyboardShortcuts.bind(this));
    },

    // Initialize UI components
    initializeComponents: function() {
        // Initialize tooltips
        this.initTooltips();
        
        // Initialize modals
        this.initModals();
        
        // Initialize dropdowns
        this.initDropdowns();
        
        // Initialize progress bars
        this.initProgressBars();
        
        // Initialize file preview
        this.initFilePreview();
    },

    // Initialize tooltips
    initTooltips: function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    },

    // Initialize modals
    initModals: function() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.addEventListener('shown.bs.modal', () => {
                const firstInput = modal.querySelector('input, textarea, select');
                if (firstInput) {
                    firstInput.focus();
                }
            });

            modal.addEventListener('hidden.bs.modal', () => {
                const forms = modal.querySelectorAll('form');
                forms.forEach(form => form.reset());
                this.clearValidationErrors(modal);
            });
        });
    },

    // Initialize dropdowns
    initDropdowns: function() {
        const dropdownElementList = [].slice.call(document.querySelectorAll('[data-bs-toggle="dropdown"]'));
        dropdownElementList.map(function(dropdownToggleEl) {
            return new bootstrap.Dropdown(dropdownToggleEl);
        });
    },

    // Initialize progress bars with animation
    initProgressBars: function() {
        const progressBars = document.querySelectorAll('.progress-bar');
        progressBars.forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0%';
            setTimeout(() => {
                bar.style.width = width;
            }, 100);
        });
    },

    // Initialize file preview functionality
    initFilePreview: function() {
        const fileInputs = document.querySelectorAll('input[type="file"]');
        fileInputs.forEach(input => {
            input.addEventListener('change', this.previewFile.bind(this));
        });
    },

    // Handle form submissions with loading states
    handleFormSubmit: function(event) {
        const form = event.target;
        if (!form.classList.contains('ajax-form')) return;

        event.preventDefault();
        
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            this.setLoadingState(submitBtn, true);
        }

        // Add form validation
        if (!this.validateForm(form)) {
            if (submitBtn) {
                this.setLoadingState(submitBtn, false);
            }
            return;
        }

        // Handle file uploads differently
        if (form.enctype === 'multipart/form-data') {
            this.handleFileUpload(form);
        } else {
            this.handleAjaxSubmit(form);
        }
    },

    // Handle file input changes
    handleFileChange: function(event) {
        const input = event.target;
        if (input.type !== 'file') return;

        const files = input.files;
        if (files.length === 0) return;

        // Validate file size and type
        for (let file of files) {
            if (!this.validateFile(file)) {
                input.value = '';
                return;
            }
        }

        // Show file preview
        this.previewFile(event);
    },

    // Handle search input with debouncing
    handleSearchInput: function(event) {
        const input = event.target;
        if (!input.classList.contains('search-input')) return;

        clearTimeout(input.searchTimeout);
        input.searchTimeout = setTimeout(() => {
            this.performSearch(input.value, input.dataset.target);
        }, 300);
    },

    // Handle window resize
    handleResize: function() {
        // Update any responsive components
        this.updateResponsiveComponents();
    },

    // Handle keyboard shortcuts
    handleKeyboardShortcuts: function(event) {
        // Ctrl/Cmd + K for global search
        if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
            event.preventDefault();
            const searchInput = document.querySelector('#globalSearch');
            if (searchInput) {
                searchInput.focus();
            }
        }

        // Escape to close modals
        if (event.key === 'Escape') {
            const activeModal = document.querySelector('.modal.show');
            if (activeModal) {
                bootstrap.Modal.getInstance(activeModal).hide();
            }
        }
    },

    // Validate form inputs
    validateForm: function(form) {
        let isValid = true;
        const requiredInputs = form.querySelectorAll('[required]');

        requiredInputs.forEach(input => {
            if (!input.value.trim()) {
                this.showFieldError(input, 'Este campo é obrigatório');
                isValid = false;
            } else {
                this.clearFieldError(input);
            }
        });

        // Email validation
        const emailInputs = form.querySelectorAll('input[type="email"]');
        emailInputs.forEach(input => {
            if (input.value && !this.isValidEmail(input.value)) {
                this.showFieldError(input, 'Email inválido');
                isValid = false;
            }
        });

        // Password validation
        const passwordInputs = form.querySelectorAll('input[type="password"]');
        passwordInputs.forEach(input => {
            if (input.value && input.value.length < 6) {
                this.showFieldError(input, 'Senha deve ter pelo menos 6 caracteres');
                isValid = false;
            }
        });

        return isValid;
    },

    // Validate file uploads
    validateFile: function(file) {
        // Check file size
        if (file.size > this.config.maxFileSize) {
            this.showAlert('Arquivo muito grande. Tamanho máximo: 100MB', 'error');
            return false;
        }

        // Check file type
        const fileExtension = file.name.split('.').pop().toLowerCase();
        if (!this.config.allowedFileTypes.includes(fileExtension)) {
            this.showAlert('Tipo de arquivo não permitido', 'error');
            return false;
        }

        return true;
    },

    // Preview file before upload
    previewFile: function(event) {
        const input = event.target;
        const file = input.files[0];
        if (!file) return;

        const previewContainer = input.closest('.form-group, .mb-3')?.querySelector('.file-preview');
        if (!previewContainer) return;

        const fileName = file.name;
        const fileSize = this.formatFileSize(file.size);
        const fileType = file.type;

        let previewHTML = `
            <div class="file-preview-item">
                <div class="d-flex align-items-center">
                    <i data-feather="file" class="me-2"></i>
                    <div class="flex-grow-1">
                        <div class="fw-medium">${fileName}</div>
                        <small class="text-muted">${fileSize}</small>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.file-preview-item').remove(); document.querySelector('#${input.id}').value = '';">
                        <i data-feather="x" width="14" height="14"></i>
                    </button>
                </div>
            </div>
        `;

        // Show image preview for image files
        if (fileType.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewHTML = `
                    <div class="file-preview-item">
                        <div class="d-flex align-items-center">
                            <img src="${e.target.result}" class="preview-image me-2" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                            <div class="flex-grow-1">
                                <div class="fw-medium">${fileName}</div>
                                <small class="text-muted">${fileSize}</small>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('.file-preview-item').remove(); document.querySelector('#${input.id}').value = '';">
                                <i data-feather="x" width="14" height="14"></i>
                            </button>
                        </div>
                    </div>
                `;
                previewContainer.innerHTML = previewHTML;
                feather.replace();
            };
            reader.readAsDataURL(file);
        } else {
            previewContainer.innerHTML = previewHTML;
            feather.replace();
        }
    },

    // Handle AJAX form submission
    handleAjaxSubmit: async function(form) {
        try {
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);
            
            const response = await fetch(form.action, {
                method: form.method || 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            
            if (result.success) {
                this.showAlert(result.message || 'Operação realizada com sucesso', 'success');
                
                // Close modal if inside one
                const modal = form.closest('.modal');
                if (modal) {
                    bootstrap.Modal.getInstance(modal).hide();
                }
                
                // Refresh page or update UI
                setTimeout(() => {
                    location.reload();
                }, 1000);
            } else {
                this.showAlert(result.message || 'Erro ao processar solicitação', 'error');
            }
        } catch (error) {
            console.error('Form submission error:', error);
            this.showAlert('Erro de conexão', 'error');
        } finally {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                this.setLoadingState(submitBtn, false);
            }
        }
    },

    // Handle file upload with progress
    handleFileUpload: async function(form) {
        try {
            const formData = new FormData(form);
            
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData
            });

            const result = await response.json();
            
            if (result.success) {
                this.showAlert('Arquivo enviado com sucesso', 'success');
                
                const modal = form.closest('.modal');
                if (modal) {
                    bootstrap.Modal.getInstance(modal).hide();
                }
                
                setTimeout(() => {
                    location.reload();
                }, 1000);
            } else {
                this.showAlert(result.message || 'Erro ao enviar arquivo', 'error');
            }
        } catch (error) {
            console.error('File upload error:', error);
            this.showAlert('Erro ao enviar arquivo', 'error');
        } finally {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                this.setLoadingState(submitBtn, false);
            }
        }
    },

    // Set loading state for buttons
    setLoadingState: function(button, isLoading) {
        if (isLoading) {
            button.disabled = true;
            button.dataset.originalText = button.innerHTML;
            button.innerHTML = '<i data-feather="loader" class="me-2"></i>Processando...';
        } else {
            button.disabled = false;
            button.innerHTML = button.dataset.originalText || button.innerHTML;
        }
        feather.replace();
    },

    // Show form field error
    showFieldError: function(input, message) {
        input.classList.add('is-invalid');
        
        let feedback = input.parentNode.querySelector('.invalid-feedback');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            input.parentNode.appendChild(feedback);
        }
        feedback.textContent = message;
    },

    // Clear form field error
    clearFieldError: function(input) {
        input.classList.remove('is-invalid');
        const feedback = input.parentNode.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.remove();
        }
    },

    // Clear all validation errors in container
    clearValidationErrors: function(container) {
        const invalidInputs = container.querySelectorAll('.is-invalid');
        invalidInputs.forEach(input => {
            this.clearFieldError(input);
        });
    },

    // Show alert message
    showAlert: function(message, type = 'info') {
        const alertHTML = `
            <div class="alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        const alertContainer = document.querySelector('.alert-container') || document.querySelector('.container-fluid');
        if (alertContainer) {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = alertHTML;
            alertContainer.insertBefore(tempDiv.firstElementChild, alertContainer.firstElementChild);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                const alert = alertContainer.querySelector('.alert');
                if (alert) {
                    const bsAlert = bootstrap.Alert.getInstance(alert);
                    if (bsAlert) {
                        bsAlert.close();
                    }
                }
            }, 5000);
        }
    },

    // Perform search functionality
    performSearch: function(query, target) {
        if (!query.trim()) return;
        
        // Implement search logic based on target
        console.log('Searching for:', query, 'in', target);
    },

    // Update responsive components
    updateResponsiveComponents: function() {
        // Update any components that need to respond to window size changes
        const tables = document.querySelectorAll('.table-responsive');
        tables.forEach(table => {
            // Add scroll indicators if needed
        });
    },

    // Setup auto-refresh for real-time data
    setupAutoRefresh: function() {
        // Only for admin and teacher dashboards
        const isDashboard = document.body.classList.contains('dashboard-page');
        if (!isDashboard) return;

        setInterval(() => {
            this.refreshDashboardData();
        }, this.config.refreshInterval);
    },

    // Refresh dashboard data
    refreshDashboardData: function() {
        // Implement dashboard data refresh
        console.log('Refreshing dashboard data...');
    },

    // Utility functions
    isValidEmail: function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    formatFileSize: function(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    formatDate: function(date) {
        return new Date(date).toLocaleDateString('pt-BR');
    },

    formatDateTime: function(date) {
        return new Date(date).toLocaleString('pt-BR');
    }
};

// API helper functions
const API = {
    // Generic API request
    request: async function(endpoint, options = {}) {
        const url = EduApp.config.apiUrl + endpoint;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            }
        };
        
        const finalOptions = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(url, finalOptions);
            return await response.json();
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    },

    // User management
    users: {
        create: (data) => API.request('/users', { method: 'POST', body: JSON.stringify(data) }),
        update: (id, data) => API.request(`/users/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
        delete: (id) => API.request(`/users/${id}`, { method: 'DELETE' })
    },

    // Class management
    classes: {
        create: (data) => API.request('/classes', { method: 'POST', body: JSON.stringify(data) }),
        update: (id, data) => API.request(`/classes/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
        delete: (id) => API.request(`/classes/${id}`, { method: 'DELETE' })
    },

    // Subject management
    subjects: {
        create: (data) => API.request('/subjects', { method: 'POST', body: JSON.stringify(data) }),
        update: (id, data) => API.request(`/subjects/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
        delete: (id) => API.request(`/subjects/${id}`, { method: 'DELETE' })
    },

    // Material management
    materials: {
        upload: (formData) => fetch(EduApp.config.apiUrl + '/materials/upload', {
            method: 'POST',
            body: formData
        }).then(r => r.json()),
        download: (id) => window.open(EduApp.config.apiUrl + `/materials/${id}/download`, '_blank'),
        delete: (id) => API.request(`/materials/${id}`, { method: 'DELETE' })
    },

    // Assignment management
    assignments: {
        create: (data) => API.request('/assignments', { method: 'POST', body: JSON.stringify(data) }),
        submit: (formData) => fetch(EduApp.config.apiUrl + '/assignments/submit', {
            method: 'POST',
            body: formData
        }).then(r => r.json()),
        grade: (id, data) => API.request(`/assignments/${id}/grade`, { method: 'POST', body: JSON.stringify(data) })
    }
};

// Global utility functions available in templates
window.EduUtils = {
    downloadMaterial: function(id) {
        API.materials.download(id);
    },

    deleteMaterial: function(id) {
        if (confirm('Tem certeza que deseja excluir este material?')) {
            API.materials.delete(id)
                .then(result => {
                    if (result.success) {
                        EduApp.showAlert('Material excluído com sucesso', 'success');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        EduApp.showAlert(result.message || 'Erro ao excluir material', 'error');
                    }
                })
                .catch(error => {
                    EduApp.showAlert('Erro ao excluir material', 'error');
                });
        }
    },

    submitAssignment: function(assignmentId) {
        const modal = document.getElementById('submitAssignmentModal');
        if (modal) {
            document.getElementById('submit_assignment_id').value = assignmentId;
            new bootstrap.Modal(modal).show();
        }
    },

    toggleView: function(view) {
        const listView = document.getElementById('listView');
        const gridView = document.getElementById('gridView');
        const listBtn = document.getElementById('listViewBtn');
        const gridBtn = document.getElementById('gridViewBtn');
        
        if (view === 'list') {
            listView.style.display = 'block';
            gridView.style.display = 'none';
            listBtn.classList.add('active');
            gridBtn.classList.remove('active');
        } else {
            listView.style.display = 'none';
            gridView.style.display = 'block';
            listBtn.classList.remove('active');
            gridBtn.classList.add('active');
        }
        
        feather.replace();
    }
};

// Initialize application when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    EduApp.init();
    
    // Initialize Feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
    
    // Mark forms that should be handled with AJAX
    const forms = document.querySelectorAll('form[data-ajax="true"]');
    forms.forEach(form => form.classList.add('ajax-form'));
    
    // Add search functionality to search inputs
    const searchInputs = document.querySelectorAll('input[placeholder*="Buscar"], input[placeholder*="Pesquisar"]');
    searchInputs.forEach(input => input.classList.add('search-input'));
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { EduApp, API };
}
