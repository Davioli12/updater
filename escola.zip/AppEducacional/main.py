from app import app
from config_loader import get_host_port_debug

if __name__ == '__main__':
    host, port, debug = get_host_port_debug()
    app.run(debug=debug, host=host, port=port)
