import sqlite3
from config_loader import get_database_name

conn = sqlite3.connect(get_database_name())
cursor = conn.cursor()

# The table already includes `enrollment_date` by default. No need to add `enrolled_at`.

# (Opcional) adiciona is_active para facilitar controle de matrícula
try:
    cursor.execute("ALTER TABLE class_students ADD COLUMN is_active INTEGER DEFAULT 1;")
    print("✅ Coluna 'is_active' adicionada com sucesso.")
except sqlite3.OperationalError as e:
    print(f"⚠️ Coluna 'is_active' já existe ou erro: {e}")

# Adiciona a coluna cpf na tabela users para armazenar CPF de alunos (se ainda não existir)
try:
    cursor.execute("ALTER TABLE users ADD COLUMN cpf VARCHAR(20);")
    print("✅ Coluna 'cpf' adicionada na tabela 'users' com sucesso.")
except sqlite3.OperationalError as e:
    print(f"⚠️ Coluna 'cpf' já existe ou erro: {e}")

conn.commit()
conn.close()
