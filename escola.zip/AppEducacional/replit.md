# Overview

This is a comprehensive educational management system built with Flask, designed for "Escola Estadual Dona Indá". The system provides a complete solution for managing students, teachers, classes, subjects, assignments, and educational materials. It features role-based access control with separate dashboards for administrators, teachers, and students, along with file upload capabilities for educational content sharing.

# User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (August 2025)
- Email field removed as requirement from user registration system to accommodate users without email addresses
- Database schema updated to make email optional in users table
- All forms and templates updated to reflect optional email field
- **MAJOR SECURITY FIX**: Enhanced authentication system with active user validation to prevent unauthorized access
- **FILE HANDLING COMPLETE**: Implemented secure file upload, download, view, and delete functionality with proper permission checks
- Fixed all file operation endpoints with comprehensive access control based on user roles and class enrollment

# System Architecture

## Backend Framework
- **Flask** as the core web framework with CORS enabled for cross-origin requests
- **SQLite** database for data persistence with direct SQL operations
- **JWT** for authentication and session management
- **Session-based** user state management with Flask sessions

## Authentication & Authorization
- **Multi-role system** supporting admin, teacher, and student user types
- **Password hashing** using hashlib for secure credential storage
- **JWT tokens** for API authentication with configurable expiration
- **Role-based access control** restricting features based on user type

## File Management
- **Secure file uploads** with filename sanitization using Werkzeug
- **File type validation** supporting videos, documents, and images
- **Configurable size limits** with default 100MB maximum
- **Organized storage** in structured upload directories

## Configuration Management
- **JSON-based configuration** system with ConfigManager class
- **Environment-specific settings** supporting development and production modes
- **Dynamic configuration loading** with fallback to default values
- **Centralized school information** management

## Frontend Architecture
- **Server-side rendering** using Jinja2 templates
- **Bootstrap 5** with dark theme for responsive UI
- **Feather Icons** for consistent iconography
- **Custom CSS** for enhanced styling and user experience
- **Progressive enhancement** with JavaScript for interactive features

## Database Design
- **Single SQLite database** with multiple related tables
- **User management** with role-based permissions
- **Class and subject** organization with teacher assignments
- **Assignment tracking** with submission capabilities
- **Material sharing** with metadata and access control

## Error Handling & Logging
- **Comprehensive logging** with file and console output
- **UTF-8 encoding** configuration for international character support
- **Graceful error handling** with user-friendly messages
- **Debug mode** support for development environments

# External Dependencies

## Core Framework Dependencies
- **Flask 3.0.0** - Web framework
- **Flask-CORS 4.0.0** - Cross-origin resource sharing
- **Werkzeug 3.0.1** - WSGI utilities and security functions
- **PyJWT 2.8.0** - JSON Web Token implementation

## Frontend Dependencies
- **Bootstrap 5** (via CDN) - CSS framework with dark theme
- **Feather Icons** (via CDN) - Icon library
- **Custom CSS/JS** - Application-specific styling and functionality

## Built-in Python Libraries
- **sqlite3** - Database operations
- **hashlib** - Password hashing
- **uuid** - Unique identifier generation
- **datetime** - Date and time handling
- **json** - Configuration file parsing
- **os/pathlib** - File system operations
- **logging** - Application logging

## Optional Future Dependencies
- **OpenAI/Transformers** - AI integration capabilities
- **Email libraries** - Notification system
- **Backup utilities** - Automated data protection
- **Production servers** - Gunicorn/Waitress for deployment

The architecture emphasizes simplicity, security, and scalability while maintaining educational institution requirements for user management, content sharing, and progress tracking.