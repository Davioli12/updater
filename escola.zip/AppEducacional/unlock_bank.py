import sqlite3
import hashlib
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime
import json

class DatabaseEditor:
    def __init__(self, db_name="school_system.db"):
        self.db_name = db_name
        self.conn = None
        self.setup_database()
        
    def setup_database(self):
        """Inicializa a base de dados"""
        self.conn = sqlite3.connect(self.db_name)
        self.conn.row_factory = sqlite3.Row
        cursor = self.conn.cursor()
        
        # Users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100),
                password_hash VARCHAR(255) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                cpf VARCHAR(20),
                user_type VARCHAR(20) NOT NULL CHECK (user_type IN ('admin', 'teacher', 'student')),
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Classes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS classes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                grade_level VARCHAR(20),
                academic_year INTEGER,
                teacher_id INTEGER,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES users (id)
            )
        """)
        
        # Subjects table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS subjects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                teacher_id INTEGER,
                class_id INTEGER,
                color VARCHAR(7) DEFAULT '#007bff',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES users (id),
                FOREIGN KEY (class_id) REFERENCES classes (id)
            )
        """)
        
        # Materials table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS materials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                file_path VARCHAR(500),
                file_type VARCHAR(20),
                file_size INTEGER,
                subject_id INTEGER,
                uploaded_by INTEGER,
                is_public BOOLEAN DEFAULT 0,
                download_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (uploaded_by) REFERENCES users (id)
            )
        """)
        
        # Class students table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS class_students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                class_id INTEGER,
                student_id INTEGER,
                enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (class_id) REFERENCES classes (id),
                FOREIGN KEY (student_id) REFERENCES users (id),
                UNIQUE(class_id, student_id)
            )
        """)
        
        # Assignments table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                subject_id INTEGER,
                teacher_id INTEGER,
                class_id INTEGER,
                due_date TIMESTAMP,
                max_grade INTEGER DEFAULT 100,
                points INTEGER DEFAULT 0,
                assignment_type VARCHAR(50) DEFAULT 'homework',
                instructions TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (teacher_id) REFERENCES users (id),
                FOREIGN KEY (class_id) REFERENCES classes (id)
            )
        """)
        
        # Assignment submissions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assignment_submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                assignment_id INTEGER,
                student_id INTEGER,
                submission_text TEXT,
                file_path VARCHAR(500),
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                grade FLOAT,
                feedback TEXT,
                graded_by INTEGER,
                graded_at TIMESTAMP,
                FOREIGN KEY (assignment_id) REFERENCES assignments (id),
                FOREIGN KEY (student_id) REFERENCES users (id),
                FOREIGN KEY (graded_by) REFERENCES users (id)
            )
        """)
        
        # Student progress table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS student_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER,
                subject_id INTEGER,
                material_id INTEGER,
                progress_percentage FLOAT DEFAULT 0,
                time_spent INTEGER DEFAULT 0,
                last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed BOOLEAN DEFAULT 0,
                FOREIGN KEY (student_id) REFERENCES users (id),
                FOREIGN KEY (subject_id) REFERENCES subjects (id),
                FOREIGN KEY (material_id) REFERENCES materials (id)
            )
        """)
        
        self.conn.commit()
        
    def get_tables(self):
        """Retorna lista de todas as tabelas"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        return [row[0] for row in cursor.fetchall()]
    
    def get_table_columns(self, table_name):
        """Retorna colunas de uma tabela"""
        cursor = self.conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        return [row[1] for row in cursor.fetchall()]
    
    def get_all_records(self, table_name):
        """Retorna todos os registros de uma tabela"""
        cursor = self.conn.cursor()
        cursor.execute(f"SELECT * FROM {table_name}")
        return cursor.fetchall()
    
    def insert_record(self, table_name, data):
        """Insere um novo registro"""
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        cursor = self.conn.cursor()
        cursor.execute(query, list(data.values()))
        self.conn.commit()
        return cursor.lastrowid
    
    def update_record(self, table_name, record_id, data):
        """Atualiza um registro existente"""
        set_clause = ', '.join([f"{k} = ?" for k in data.keys()])
        query = f"UPDATE {table_name} SET {set_clause} WHERE id = ?"
        cursor = self.conn.cursor()
        cursor.execute(query, list(data.values()) + [record_id])
        self.conn.commit()
    
    def delete_record(self, table_name, record_id):
        """Deleta um registro"""
        cursor = self.conn.cursor()
        cursor.execute(f"DELETE FROM {table_name} WHERE id = ?", (record_id,))
        self.conn.commit()
    
    def execute_custom_query(self, query):
        """Executa query SQL customizada"""
        cursor = self.conn.cursor()
        cursor.execute(query)
        self.conn.commit()
        return cursor.fetchall()


class DatabaseEditorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Editor Completo de Banco de Dados - Sistema Educacional")
        self.root.geometry("1200x700")
        self.db = DatabaseEditor()
        
        # Estilo
        style = ttk.Style()
        style.theme_use('clam')
        
        self.setup_ui()
        self.load_tables()
        
    def setup_ui(self):
        """Configura a interface"""
        # Frame principal
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configurar grid
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Lista de tabelas
        ttk.Label(main_frame, text="Tabelas:", font=('Arial', 12, 'bold')).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.table_listbox = tk.Listbox(main_frame, width=30, height=20, font=('Arial', 10))
        self.table_listbox.grid(row=1, column=0, sticky=(tk.N, tk.S), padx=(0, 10))
        self.table_listbox.bind('<<ListboxSelect>>', self.on_table_select)
        
        scrollbar_tables = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=self.table_listbox.yview)
        scrollbar_tables.grid(row=1, column=0, sticky=(tk.N, tk.S, tk.E))
        self.table_listbox.config(yscrollcommand=scrollbar_tables.set)
        
        # Frame de dados
        data_frame = ttk.Frame(main_frame)
        data_frame.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        data_frame.columnconfigure(0, weight=1)
        data_frame.rowconfigure(0, weight=1)
        
        # Treeview para exibir dados
        self.tree = ttk.Treeview(data_frame, show='tree headings')
        self.tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Scrollbars para treeview
        vsb = ttk.Scrollbar(data_frame, orient="vertical", command=self.tree.yview)
        vsb.grid(row=0, column=1, sticky=(tk.N, tk.S))
        hsb = ttk.Scrollbar(data_frame, orient="horizontal", command=self.tree.xview)
        hsb.grid(row=1, column=0, sticky=(tk.E, tk.W))
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Botões de ação
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=10)
        
        ttk.Button(button_frame, text="➕ Novo Registro", command=self.add_record).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="✏️ Editar", command=self.edit_record).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="🗑️ Deletar", command=self.delete_record).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="🔄 Atualizar", command=self.refresh_data).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="📝 SQL Customizado", command=self.execute_custom_sql).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="📊 Exportar JSON", command=self.export_json).pack(side=tk.LEFT, padx=5)
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Pronto")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
    def load_tables(self):
        """Carrega lista de tabelas"""
        self.table_listbox.delete(0, tk.END)
        tables = self.db.get_tables()
        for table in tables:
            self.table_listbox.insert(tk.END, table)
        self.status_var.set(f"{len(tables)} tabelas encontradas")
        
    def on_table_select(self, event):
        """Quando uma tabela é selecionada"""
        selection = self.table_listbox.curselection()
        if not selection:
            return
        
        table_name = self.table_listbox.get(selection[0])
        self.current_table = table_name
        self.load_table_data(table_name)
        
    def load_table_data(self, table_name):
        """Carrega dados de uma tabela"""
        # Limpar treeview
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Obter colunas
        columns = self.db.get_table_columns(table_name)
        self.tree['columns'] = columns
        
        # Configurar colunas
        self.tree.column('#0', width=0, stretch=tk.NO)
        for col in columns:
            self.tree.column(col, width=120, anchor=tk.W)
            self.tree.heading(col, text=col, anchor=tk.W)
        
        # Carregar dados
        records = self.db.get_all_records(table_name)
        for record in records:
            values = [record[col] for col in columns]
            self.tree.insert('', tk.END, values=values)
        
        self.status_var.set(f"Tabela '{table_name}' - {len(records)} registros")
        
    def add_record(self):
        """Adiciona novo registro"""
        if not hasattr(self, 'current_table'):
            messagebox.showwarning("Aviso", "Selecione uma tabela primeiro")
            return
        
        columns = self.db.get_table_columns(self.current_table)
        # Remover id e timestamps automáticos
        editable_columns = [col for col in columns if col not in ['id', 'created_at', 'updated_at']]
        
        # Criar janela de diálogo
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Novo Registro - {self.current_table}")
        dialog.geometry("500x600")
        
        entries = {}
        
        canvas = tk.Canvas(dialog)
        scrollbar = ttk.Scrollbar(dialog, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        for i, col in enumerate(editable_columns):
            ttk.Label(scrollable_frame, text=f"{col}:", font=('Arial', 10)).grid(row=i, column=0, sticky=tk.W, padx=10, pady=5)
            entry = ttk.Entry(scrollable_frame, width=40)
            entry.grid(row=i, column=1, padx=10, pady=5)
            entries[col] = entry
        
        def save():
            data = {}
            for col, entry in entries.items():
                value = entry.get()
                if value:
                    # Tratamento especial para senhas
                    if col == 'password_hash' and self.current_table == 'users':
                        value = hashlib.sha256(value.encode()).hexdigest()
                    data[col] = value
            
            try:
                self.db.insert_record(self.current_table, data)
                messagebox.showinfo("Sucesso", "Registro inserido com sucesso!")
                dialog.destroy()
                self.refresh_data()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao inserir: {str(e)}")
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        ttk.Button(dialog, text="Salvar", command=save).pack(pady=10)
        
    def edit_record(self):
        """Edita registro selecionado"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Aviso", "Selecione um registro para editar")
            return
        
        item = self.tree.item(selected[0])
        values = item['values']
        columns = self.db.get_table_columns(self.current_table)
        
        record_id = values[0]  # Assumindo que ID é sempre a primeira coluna
        
        # Criar janela de diálogo
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Editar Registro - {self.current_table} (ID: {record_id})")
        dialog.geometry("500x600")
        
        entries = {}
        
        canvas = tk.Canvas(dialog)
        scrollbar = ttk.Scrollbar(dialog, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        for i, col in enumerate(columns):
            if col == 'id':
                continue
            
            ttk.Label(scrollable_frame, text=f"{col}:", font=('Arial', 10)).grid(row=i, column=0, sticky=tk.W, padx=10, pady=5)
            entry = ttk.Entry(scrollable_frame, width=40)
            entry.insert(0, str(values[i]) if values[i] is not None else "")
            entry.grid(row=i, column=1, padx=10, pady=5)
            entries[col] = entry
        
        def save():
            data = {}
            for col, entry in entries.items():
                value = entry.get()
                if col == 'password_hash' and self.current_table == 'users' and value:
                    value = hashlib.sha256(value.encode()).hexdigest()
                if value:
                    data[col] = value
            
            try:
                self.db.update_record(self.current_table, record_id, data)
                messagebox.showinfo("Sucesso", "Registro atualizado com sucesso!")
                dialog.destroy()
                self.refresh_data()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao atualizar: {str(e)}")
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        ttk.Button(dialog, text="Salvar", command=save).pack(pady=10)
        
    def delete_record(self):
        """Deleta registro selecionado"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Aviso", "Selecione um registro para deletar")
            return
        
        item = self.tree.item(selected[0])
        record_id = item['values'][0]
        
        if messagebox.askyesno("Confirmar", f"Deletar registro ID {record_id}?"):
            try:
                self.db.delete_record(self.current_table, record_id)
                messagebox.showinfo("Sucesso", "Registro deletado com sucesso!")
                self.refresh_data()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao deletar: {str(e)}")
    
    def refresh_data(self):
        """Atualiza dados da tabela atual"""
        if hasattr(self, 'current_table'):
            self.load_table_data(self.current_table)
    
    def execute_custom_sql(self):
        """Executa SQL customizado"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Executar SQL Customizado")
        dialog.geometry("600x400")
        
        ttk.Label(dialog, text="Digite sua query SQL:", font=('Arial', 11, 'bold')).pack(pady=10)
        
        text_widget = tk.Text(dialog, height=10, width=70, font=('Courier', 10))
        text_widget.pack(padx=10, pady=10)
        
        result_text = tk.Text(dialog, height=10, width=70, font=('Courier', 9))
        result_text.pack(padx=10, pady=10)
        
        def execute():
            query = text_widget.get("1.0", tk.END).strip()
            try:
                results = self.db.execute_custom_query(query)
                result_text.delete("1.0", tk.END)
                result_text.insert("1.0", f"Executado com sucesso!\n\nResultados:\n{results}")
                self.refresh_data()
            except Exception as e:
                result_text.delete("1.0", tk.END)
                result_text.insert("1.0", f"Erro: {str(e)}")
        
        ttk.Button(dialog, text="Executar", command=execute).pack(pady=5)
    
    def export_json(self):
        """Exporta tabela atual para JSON"""
        if not hasattr(self, 'current_table'):
            messagebox.showwarning("Aviso", "Selecione uma tabela primeiro")
            return
        
        records = self.db.get_all_records(self.current_table)
        columns = self.db.get_table_columns(self.current_table)
        
        data = []
        for record in records:
            row_dict = {columns[i]: record[i] for i in range(len(columns))}
            data.append(row_dict)
        
        filename = f"{self.current_table}_export.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        messagebox.showinfo("Sucesso", f"Dados exportados para {filename}")


if __name__ == "__main__":
    root = tk.Tk()
    app = DatabaseEditorGUI(root)
    root.mainloop()