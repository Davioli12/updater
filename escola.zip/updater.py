import zipfile
import subprocess
import time
import os
import sys

APP_FILE = "main.py"
ZIP_FILE = "escola.zip"

# espera o app fechar completamente
time.sleep(2)

# extrai os arquivos do update
with zipfile.ZipFile(ZIP_FILE, "r") as zip_ref:
    zip_ref.extractall(".")

# remove o zip após instalar
os.remove(ZIP_FILE)

# reabre o app atualizado
subprocess.Popen([sys.executable, APP_FILE])

# fecha o updater
sys.exit(0)
