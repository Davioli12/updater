# 🧩 PaaS Local — Plataforma de Gerenciamento de Serviços

## 📌 Visão Geral

O **PaaS Local** é uma plataforma desenvolvida em **Python** para **gerenciamento e monitoramento de serviços executados localmente**, oferecendo um **painel web centralizado** para controle de processos.

O projeto aplica conceitos reais de **PaaS (Platform as a Service)** em ambiente local, permitindo administrar diferentes tipos de serviços de forma unificada, segura e organizada, sem depender de infraestrutura em nuvem.

---

## 🧠 Conceito

Um **PaaS (Platform as a Service)** atua como uma camada intermediária entre o sistema operacional e as aplicações, sendo responsável por:

- Iniciar e encerrar serviços
- Monitorar estado de execução
- Gerenciar variáveis de ambiente
- Controlar portas e processos
- Centralizar a administração

O **PaaS Local** traz esse conceito para uso local, servindo como uma central de serviços para ambientes de desenvolvimento, laboratórios, servidores domésticos ou estudo de arquitetura de sistemas.

---

## ✨ Funcionalidades Principais

### 🔹 Gerenciamento de Serviços
- Iniciar serviços sob demanda
- Parar serviços em execução
- Reiniciar serviços
- Prevenção de execução duplicada

### 🔹 Monitoramento de Processos
- Controle baseado em PID
- Detecção real de estado (rodando/parado)
- Encerramento seguro de processos e subprocessos
- Compatível com serviços iniciados via shell

### 🔹 Detecção Automática de Portas
- Identificação das portas utilizadas por cada serviço
- Suporte a múltiplas portas por processo
- Funciona com serviços iniciados por scripts, executáveis ou interpretadores
- Detecção baseada em conexões reais do sistema

### 🔹 Painel Web
- Interface acessível via navegador
- Visualização clara do estado dos serviços
- Controles diretos para iniciar, parar e reiniciar
- Atualização periódica do status

### 🔹 Persistência de Estado
- Registro de informações de execução em disco
- Controle consistente mesmo após reinicialização do painel
- Evita inconsistências de processos órfãos

### 🔹 Autenticação
- Sistema de login para acesso ao painel
- Proteção de rotas sensíveis
- Controle de sessão

---

## 🏗️ Arquitetura

O sistema é organizado em camadas bem definidas:

### 1️⃣ Gerenciador de Serviços
Responsável por:
- Ler configurações
- Iniciar processos
- Encerrar processos
- Monitorar PID e estado
- Detectar portas em uso
- Gerenciar subprocessos

Essa camada é independente da interface web.

---

### 2️⃣ Backend Web
Responsável por:
- Disponibilizar o painel web
- Expor endpoints de controle
- Gerenciar autenticação
- Integrar o gerenciador de serviços à interface

Utiliza **Flask** como framework web.

---

### 3️⃣ Interface Web
Responsável por:
- Exibir serviços e status
- Mostrar portas ativas
- Disponibilizar ações de controle
- Atualizar informações periodicamente

Construída com **HTML**, **Jinja2**, **Bootstrap** e **JavaScript**.

---

## 📦 Configuração de Serviços

Os serviços são definidos em um arquivo de configuração em **JSON**, permitindo especificar:

- Nome do serviço
- Comando de execução
- Diretório de trabalho
- Inicialização automática
- Variáveis de ambiente opcionais

Essa abordagem torna o sistema flexível e adaptável a diferentes tipos de aplicações.

---

## 🔐 Segurança

O PaaS Local inclui mecanismos básicos de segurança, como:

- Autenticação de usuários
- Proteção de rotas do painel
- Controle de processos
- Prevenção de duplicação de serviços

Recomenda-se o uso em ambientes controlados, como redes locais ou máquinas de desenvolvimento.

---

## 🖥️ Compatibilidade

### Sistemas Operacionais
- Windows
- Linux
- macOS

### Tipos de Serviços
- Aplicações Python
- Servidores web
- Scripts de inicialização
- Executáveis
- Serviços em background
- Servidores de jogos

---

## 🧠 Detalhes Técnicos

### Gerenciamento de Processos
- Uso de grupos de processo
- Encerramento recursivo (processo pai e filhos)
- Compatibilidade com processos iniciados via shell

### Detecção de Portas
- Baseada em inspeção de conexões de rede por PID
- Inclui processos filhos (essencial em alguns sistemas)
- Não depende de logs ou parsing de saída

### Estabilidade
- Tratamento de exceções para processos inexistentes
- Evita travamentos por processos órfãos
- Controle consistente do estado dos serviços

---

## 📚 Tecnologias Utilizadas

- Python
- Flask
- psutil
- HTML / CSS
- Bootstrap
- Jinja2
- JavaScript (Fetch API)

---

## 📄 Licença

Projeto de uso educacional e experimental.  
Pode ser adaptado livremente conforme a necessidade.

---

## ✅ Conclusão

O **PaaS Local** é uma solução robusta para **gerenciamento centralizado de serviços locais**, oferecendo controle real de processos, visualização clara de estado e uma arquitetura limpa.

O projeto demonstra conhecimentos sólidos em:
- Backend
- Sistemas operacionais
- Gerenciamento de processos
- Arquitetura de software

Sendo adequado tanto para uso prático quanto para fins educacionais e de portfólio.
