import requests
import sys

def prt(*args):
    try:
        print(*args)
    except:
        pass

def verificar_licenca(chave_licenca, server='localhost:5000'):
    url = f"http://{server}/api/licenses/{chave_licenca}/verify"
    
    try:
        response = requests.post(url, timeout=10)
        data = response.json()
        
        if data.get('valid'):
            prt("✅ Licença válida!")
            prt(f"📋 Programa: {data['program_name']}")
            
            if data.get('expires_at'):
                prt(f"⏰ Expira: {data['expires_at']}")
            
            if data.get('remaining_uses'):
                prt(f"🔢 Usos restantes: {data['remaining_uses']}")
            
            return True, data
        else:
            prt(f"❌ Licença inválida: {data['error']}")
            return False, data
            
    except Exception as e:
        prt(f"🚫 Erro ao verificar licença: {e}")
        return False, e