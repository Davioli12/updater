import subprocess
import time
import os

time.sleep(2)

subprocess.Popen(["python", "main.py"])
os.exit(0)
