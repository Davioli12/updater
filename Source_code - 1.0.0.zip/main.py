import tkinter as tk
from licence_manager import *
import threading
import subprocess

# Update version
LOCAL_VERSION = "1.1.0"

import requests

UPDATE_URL = "https://raw.githubusercontent.com/Davioli12/updater/refs/heads/main/update.json"

def check_update():
    r = requests.get(UPDATE_URL, timeout=5)
    r.raise_for_status()

    data = r.json()

    if data["version"] != LOCAL_VERSION:
        return True, data

    return False, None

def download_update(url):
    r = requests.get(url, stream=True)
    
    with open("update.zip", "wb") as f:
        for chunk in r.iter_content(1024):
            f.write(chunk)

import hashlib

def validate_update(file_path, expected_hash):
    h = hashlib.sha256()

    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)

    return h.hexdigest() == expected_hash

has_update, data = check_update()

if has_update:
    download_update(data["url"])

    if validate_update("update.zip", data["sha256"]):
        subprocess.Popen(["python", "updater.py"])
        exit()
    else:
        print("Update corrompido")



class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Aplicativo licenciado")
        self.geometry("800x600")
        self.resizable(False, False)

        # inicia com o frame de login
        self.frame_login()

    def clear_frame(self):
        """Remove todos os widgets do frame atual"""
        for widget in self.winfo_children():
            widget.destroy()

    def frame_login(self):
        self.clear_frame()

        frame = tk.Frame(self)
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text="Insira sua chave abaixo:").pack(pady=5)

        entry_key = tk.Entry(frame)
        entry_key.pack(pady=5)

        self.value_key = entry_key.get().strip()

        tk.Button(
            frame,
            text="Entrar",
            command=lambda: self.verificar_licenca(self.value_key)
        ).pack(pady=5)

        self.info_label = tk.Label(frame, text='')
        self.info_label.pack(pady=5)

        self.validy = tk.Label(frame, text='Verificar primeiro')
        self.validy.pack(pady=5)

    def verificar_licenca(self, key):
        print(key)
        if key == '':
            return False

        license = verificar_licenca(chave_licenca=key)
        self.state, self.date = license
        print(self.state, self.date)

        if self.state:
            

            # troca para o dashboard
            self.frame_dashboard()
            return True
        
        return False
    def _verify_loop(self):
        self.after(30000, self._verify_loop)
        print('Verificando...')
        license = verificar_licenca(chave_licenca=self.value_key)
        self.state, self.date = license


    def frame_dashboard(self):
        self.clear_frame()

        t = threading.Thread(target=self._verify_loop, daemon=True)
        t.start()

        frame = tk.Frame(self)
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text="Dashboard ativo!").pack(pady=20)
        tk.Button(frame, text="Sair", command=self.frame_login).pack(pady=10)


app = App()
app.mainloop()